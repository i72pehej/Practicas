/*!
   \file  Monomio.cpp
   \brief Fichero que contiene el código de las funciones de la clase Monomio
*/


//  Ficheros de cabecera
#include <iostream>

#include "Monomio.hpp"

ed::Monomio & ed::Monomio::operator=(ed::Monomio const &m)
{
    // COMPLETAR
	return *this;
}

ed::Monomio & ed::Monomio::operator=(double const &x)
{
	// COMPLETAR
	return *this;
}

//////////////////////////////////////////////////////////////


ed::Monomio & ed::Monomio::operator+=(ed::Monomio const &m)
{
  // COMPLETAR
	return *this;
}



ed::Monomio & ed::Monomio::operator-=(ed::Monomio const &m)
{
    // COMPLETAR
	return *this;
}


ed::Monomio & ed::Monomio::operator*=(ed::Monomio const &m)
{
	// COMPLETAR
    return *this;
}

ed::Monomio & ed::Monomio::operator*=(double const &x)
{
	// COMPLETAR
    return *this;
}



ed::Monomio & ed::Monomio::operator/=(ed::Monomio const &m)
{
    // COMPLETAR
    return *this;
}

ed::Monomio & ed::Monomio::operator/=(double const &x)
{
	// COMPLETAR
    return *this;
}


///////////////////////////////////////////////////////////////////////
// COMPLETAR

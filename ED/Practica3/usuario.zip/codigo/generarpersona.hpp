#ifndef GENERAR_PERSONA_HPP
#define GENERAR_PERSONA_HPP

#include "persona.hpp"

Persona generarDatosPersonales();

#endif //__GENERAR_ALUMNO_HPP__

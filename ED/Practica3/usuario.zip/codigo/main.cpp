#include <iostream>
#include <cstdlib> //para usar srand()

#include "arbolbinarioordenadoenlazado.hpp"
#include "operadornodo.hpp"
#include "persona.hpp"
#include "generarpersona.hpp"

using namespace ed;

int main()
{
  srand(time(0));
  ArbolBinarioOrdenadoEnlazado<Persona> a;

  // TODO
}

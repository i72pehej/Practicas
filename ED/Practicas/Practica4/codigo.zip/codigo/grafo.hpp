#ifndef __GRAFO_HPP__
#define __GRAFO_HPP__

#include <cassert>
#include <iostream>

using namespace std;

namespace ed
{

	template <class G_Nodo, class G_Lado>
	class Grafo
	{
	private:

		G_Lado **_lados;

		G_Nodo *_nodos;

	public:

		// constructores
		// TODO

		// destructor
		// TODO

		// funciones
		// TODO
		void borrarGrafo() {	// cabecera indicada para que compile

		}

	};
}

#endif

#include <iostream>
#include <cstring>
#include <cstdlib> //Para usar system
#include <fstream> //Para trabajar con ficheros

#include "grafo.hpp"
#include "algoritmosgrafos.hpp"
#include "funciones.hpp"

using namespace std;
using namespace ed;

int main()
{
	Grafo<string, int> *g;
	AlgoritmosGrafos<string, int> p;
	int opcion;
	bool grafoIntroducido = false;

	do {
		opcion = menu();
		switch (opcion) {
			case 1:
			if(grafoIntroducido){
				g->borrarGrafo();
			}
			grafoIntroducido = cargarGrafo(g);
			g->mostrarvector();
			g->mostrarmatriz();
			if (grafoIntroducido) {
				cout << "Grafo cargado correctamente \n";
				{	
					Grafo<string, int> g1= *g;
					cout<<"comprobacion operador ="<<endl;
					g1.mostrarvector();
					g1.mostrarmatriz();
				}
			}
			else{
				cout << "Grafo no cargado \n";
				
				}

			getchar();
			getchar();
			break;

			case 2: //Algoritmo de Floyd

			if ( grafoIntroducido )
				algoritmoFloyd(*g);
			else
				cout << "Primero tiene que introducir un grafo\n";
			getchar();
			getchar();
			break;
		}
	} while (opcion!=0);

	return 0;
}

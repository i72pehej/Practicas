#ifndef __ALGORITMOSGRAFOS_H__
#define __ALGORITMOSGRAFOS_H__
#include <iostream>

#include "grafo.hpp"
using namespace ed;
using namespace std;

template <class G_Nodo, class G_Lado>
class AlgoritmosGrafos
{
public:

void calcularDistancia(Grafo<G_Nodo, G_Lado> &g){
	int aux;
	for (int k = 0; k < g.getTam(); k++)
	{
		for (int i = 0; i < g.getTam(); i++)
		{
			g.setNlado(i,i, 0);
			for (int j = 0; j < g.getTam(); j++)
    		{

        		if (g.elemL(i,k) + g.elemL(k,j) < g.elemL(i,j)){
            		aux = g.elemL(i,k) + g.elemL(k,j);
            		g.setNlado(i,j,aux);
            		g.setNrecorrido(i,j,k);
        		}
        	}
    	}
	}
	for(int i=0; i<g.getTam(); i++){
	  for(int j=0; j<g.getTam(); j++){
	  	if(g.elemR(i,j)==j){
	    g.setNrecorrido(i,j,-1);
	    }
	  }
	}
	cout<<"matriz de recorrido"<<endl;
	g.mostrarmatrizR();
	cout<<"matriz de distnacias"<<endl;
	g.mostrarmatriz();
}
string traducir(int x){
	string ciudad;
	if(x==0){
		ciudad="Almeria";
		return ciudad;
	}
	else if(x==1){
		ciudad="Cadiz";
		return ciudad;
	}
	else if(x==2){
		ciudad="Cordoba";
		return ciudad;
	}
	else if(x==3){
		ciudad="Granada";
		return ciudad;
	}
	else if(x==4){
		ciudad="Huelva";
		return ciudad;
	}
	else if(x==5){
		ciudad="Jaen";
		return ciudad;
	}
	else if(x==6){
		ciudad="Malaga";
		return ciudad;
	}
	else if(x==7){
		ciudad="Sevilla";
		return ciudad;
	}
	return ciudad;
}
void caminoMinimo(int i , int j, Grafo<G_Nodo, G_Lado> &g){
		cout<<"distancia del recorrido: "<<g.elemL(i,j)<<endl;;
		cout<<"recorrido a realizar"<<endl;
		cout<<traducir(i)<<">";
		while(g.elemR(i,j)!=-1){
			i=g.elemR(i,j);
			cout<<traducir(i)<<">";
		}
		cout<<traducir(j)<<endl;
	
	}
};

#endif

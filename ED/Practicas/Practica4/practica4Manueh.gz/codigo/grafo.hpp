#ifndef __GRAFO_HPP__
#define __GRAFO_HPP__

#include <cassert>
#include <iostream>
#include <fstream>
using namespace std;

namespace ed
{

	template <class G_Nodo, class G_Lado>
	class Grafo
	{
	private:

		G_Lado **_lados;

		G_Nodo *_nodos;

		G_Lado **_recorrido;

		int _tam;

	public:

		// constructores
	 Grafo(){
		 _nodos=NULL;
		 _lados=NULL;
	 }
	 Grafo(int n){
		 _nodos= new G_Nodo[n];
		 _lados= new G_Lado* [n];
		 for (int  i = 0; i < n; i++) {
		 	_lados[i]= new G_Lado[n];
		 }
	 }

	 Grafo( Grafo<string, int> *g){
		 this=g;
	 }
		// destructor
		~Grafo(){
			/*borrarGrafo();
			cout<<"destructor usado"<<endl;*/
		}

		// funciones
		// TODO

		bool estavacio(){
			if(_nodos==NULL && _lados==NULL){
				return true;
			}
			else{
				return false;
			}
		}
		void setTam(int n){
			_tam=n;
		}

		int numeroNodos(string fichero){
  			int tam=0;
  			string aux;

  			fstream archivo_entrada;
  			cout<<fichero<<endl;
  			archivo_entrada.open(fichero.c_str());
  			while(!archivo_entrada.eof()){
  				getline(archivo_entrada,aux);
  				tam++;
  			}
  			archivo_entrada.close();
  			_tam=tam;
  			return tam;
		}

		void MatrizRecorrido(){
			_recorrido= new G_Lado * [_tam];
				for (int i = 0; i < _tam; i++) {
		 			_recorrido[i]= new G_Lado[_tam];
				}

			for(int i=0; i<_tam; i++){
				//_recorrido[0][i]=_nodos[i];
				for(int j=0; j<_tam; j++){
					//cout<<elemN(i)<<endl; 

					 _recorrido[j][i]= i;
					
				}
			_recorrido[i][i]=-1;
			}

		}
		int getTam(){
			return _tam;
		}
		void reservaVector( int n){
			_nodos= new G_Nodo [n];
		}
		void reservaMatriz(int n){
			_lados= new G_Lado * [n];
			for (int i = 0; i < n; i++) {
		 		_lados[i]= new G_Lado[n];
			}
		}
		int Nnodos(){
			return sizeof(*_nodos);
		}
		void setNnodo(int i, string aux){
			this->_nodos[i]=aux;
		}

		void setNlado(int i, int j, int aux){
			this->_lados[i][j]=aux;
		}

		void setNrecorrido(int i, int j, int aux){
			this->_recorrido[i][j]=aux;
		}

		G_Nodo elemN(int i){
			return this->_nodos[i];
		}
		int elemL(int i, int j){
			return this-> _lados[i][j];
		}
		G_Lado elemR(int i, int j){
			return this-> _recorrido[i][j];
		}
		void mostrarvector(){
			for (int i = 0; i < getTam(); ++i)
			{
				cout<<this->_nodos[i]<<endl;
			}
		}

		void mostrarmatriz(){
			for(int i=0; i<_tam; i++){
				
				for(int j=0; j<_tam; j++){
					cout<<"["<<elemL(j,i)<<"]\t";
				}
				cout<<endl;
			}

		}

		void mostrarmatrizR(){
			for(int i=0; i<_tam; i++){
				
				for(int j=0; j<_tam; j++){
					cout<<"["<<elemR(j,i)<<"]\t";
				}
				cout<<endl;
			}

		}
		void borrarGrafo(){	// cabecera indicada para que compile
				if(estavacio()){
					cout<<"Grafo vacio"<<endl;
				}
				else{
					delete [] _nodos;

					for (int i = 0; i < _tam; i++) {
						delete []_lados[i];
					}
						delete []_lados;
						_tam=0;
				}
			}

		Grafo & operator =(Grafo<G_Nodo, G_Lado>& g){
			if(!this->estavacio()){
				this->borrarGrafo();
			}
			this->setTam(g.getTam());
			this->reservaVector(this->getTam());
			this->reservaMatriz(this->getTam());
			//igualamos
			if(!g.estavacio()){
				for(int i=0; i<this->getTam(); i++){
					this->setNnodo(i,g.elemN(i));
					for(int j=0; j<this->getTam(); j++){
						this->setNlado(i,j,g.elemL(i,j));
					}
				}
			}
		}
	};
}

#endif

#ifndef __FUNCIONES_HPP
#define __FUNCIONES_HPP

#include <iostream>
#include <cstring>
#include <sstream>
#include <cstdio>
#include <fstream>
#include <cstdlib> //Para usar system
#include <fstream> //Para trabajar con ficheros

#include "grafo.hpp"
#include "algoritmosgrafos.hpp"

using namespace std;
using namespace ed;

int menu()
{
  int opcion;

  system("clear");
  cout << "  0. Salir................................\n";
  cout << "  1. Cargar grafo desde fichero...........\n";
  cout << "  2. Algoritmo de Floyd (GD y GND)......\n";

  cout << "Introduzca opcion...:";
  cin >> opcion;

  return opcion;
}

template <class G_Nodo, class G_Lado>
bool cargarGrafo(Grafo<G_Nodo, G_Lado> * &g)
{
  
  string ficheroMatriz, ficheroEtiquetas;
  char linea2[80];
  string linea;
  char *token;
  int i=0;
  int aux;
  string palabra;
  int tam;

  //cout << "Fichero de la matriz de conexion: ";
  ficheroMatriz="matrizAndalucia.txt";

  //cout << "Fichero de las etiquetas: ";
  ficheroEtiquetas="Andalucia.txt";
  
  tam=g->numeroNodos(ficheroEtiquetas);

  g->setTam(tam);
  g->reservaVector(tam);
  g->reservaMatriz(tam);
  ifstream archivo_entrada;
  ifstream archivo_entrada2;

  //cargar vector
  archivo_entrada.open(ficheroEtiquetas.c_str());
  while(!archivo_entrada.eof()){
    getline(archivo_entrada, linea);
    g->setNnodo(i,linea);
    i++;
  }
  archivo_entrada.close();
  //cargar matriz
  FILE *fp= fopen(ficheroMatriz.c_str(),"r");
  if(fp==NULL){
    exit(-1);
  }
  for(int i=0; i<g->getTam(); i++){
    fgets(linea2,79,fp);
    token=strtok(linea2, " ");
    aux=atoi(token);
    g->setNlado(i,0,aux);
    for(int j=1; j<g->getTam(); j++){
      token = strtok(NULL, " ");
      aux=atoi(token);
      g->setNlado(i,j,aux);
    }

  }
  fclose(fp);

  return true;

}

template <class G_Nodo, class G_Lado>
void algoritmoFloyd(Grafo<G_Nodo, G_Lado> &g)
{
  int inicio;
  int final;
  AlgoritmosGrafos<string, int> p;
  g.MatrizRecorrido();
  p.calcularDistancia(g);
  cout<<endl;
  cout<<"Almeria(0)\n"<<"Cadiz(1)\n"<<"Cordoba(2)\n"<<"Granada(3)\n"<<"Huelva(4)\n"
  <<"Jaen(5)\n"<<"Malaga(6)\n"<<"Sevilla(7)\n"<<endl;
  cout<<"seleccione ciudad de salida"<<endl;
  cin>>inicio;
  cout<<"seleccione ciudad de destino"<<endl;
  cin>>final;
  p.caminoMinimo(inicio, final, g);

}

#endif

#ifndef COMMON_H_
#define COMMON_H_

#define SERVER_QUEUE  "/server_queue"
#define CLIENT_QUEUE  "/client_queue"
#define MAX_SIZE     1024
#define MSG_STOP     "exit"


#endif /* #ifndef COMMON_H_ */

#!/bin/bash
sleep 3
echo "Bienvenido $USER, tu identificador es $UID."
echo "Esta es la shell número $SHLVL, que lleva $SECONDS arrancada."
echo "La arquitectura de esta máquina es $MACHTYPE y el cliente de terminal es $TERM"

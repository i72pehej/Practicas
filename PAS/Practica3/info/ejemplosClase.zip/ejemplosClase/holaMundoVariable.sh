#!/bin/bash
STR="HOLA MUNDO!"
echo $STR

#include <stdio.h>

void main()
{
  printf("Hola Mundo\n");	
}
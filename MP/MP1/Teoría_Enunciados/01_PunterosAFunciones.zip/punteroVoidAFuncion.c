#include <stdio.h>
int escribeChar (void *c, int num)
{
 int i;

 char *cadena = (char *)c;
 for (i=0; i<num; i++)
 printf ("%c", cadena[i]);
 return 1;
}
int escribeInt (void *v, int num)
{
 int i;
 
 int *entero = (int *)v;
 for (i=0; i<num; i++)
 printf ("%d", entero[i]);
 return 0;
}

void escribe (void *p, int n, int (*funcptr)(void *, int))
{
 int tipo;
 tipo = (*funcptr)(p, n);
 if (tipo ==1)
   printf (" Cadena\n");
 else  
   printf (" Entero\n");
}

int main(void)
{
 char cad[3] = {'a','b','c'};
 int vect[5] = {2,3,4,5,6};
 escribe (cad, 3, &escribeChar);
 escribe (vect, 5, &escribeInt);
} 
/*------------------------------------------------------------------*/
/* EJEMPLO BASICO DE PUNTEROS A FUNCIONES EN C                      */
/*------------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#define MAX_ELEM 10

struct miEstructura
{
  int campo;	
};

/*******************************************************************/
/*
   Nombre: comparaEnteros.
   Tipo: int.
   Objetivo: Compara dos elementos de tipo entero.	     
   Parametros de entrada:
      - void const * e1, e2: elementos a comparar.
   Precondiciones: Ninguna.
   Devuelve:
      -1 si e1<e2
      0 si e1==e2
      1 si e1>e2
   Fecha de creaci�n: 16-05-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int comparaEnteros(const void* e1 , const void* e2)
{	
  //Los argumentos de la funcion de comparacion tienen que ser
  //de tipo  const void*
  
  int* a, *b;
  
  //Para trabajar, copiamos los argumentos en variables del tipo correcto
  a = (int*)e1;
  b = (int*)e2;

  if(*a<*b)
    return (-1);
  else if(*a==*b)
    return(0);
  else
    return(1);
}
/*******************************************************************/
/*
   Nombre: comparaEstructuras.
   Tipo: int.
   Objetivo: Compara dos elementos de tipo struct miEstructura.	     
   Parametros de entrada:
      - const void* e1, e2: elementos a comparar.
   Precondiciones: Ninguna.
   Devuelve:
      -1 si e1<e2
      0 si e1==e2
      1 si e1>e2
   Fecha de creaci�n: 16-05-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int comparaEstructuras(const void* e1 , const void* e2)
{
  struct miEstructura *a, *b;

  a = (struct miEstructura *)e1;
  b = (struct miEstructura*)e2;

  if(a->campo<b->campo)
    return (-1);
  else if(a->campo==b->campo)
    return(0);
  else
    return(1);  
  	
}
/*------------------------------------------------------------------*/
/*                       PROGRAMA PRINCIPAL                         */
/*------------------------------------------------------------------*/
main()
{
 int* v = NULL;
 int* posicion;
 struct miEstructura* posicionEstr;
 struct miEstructura* vEstructuras =NULL; 
 struct miEstructura estrAux={9}; //Declaracion e inicializacion de la estructura
 int intAux = 8, i;
   
 //Reserva de memoria
 v = (int *)malloc(MAX_ELEM * sizeof(int));
 vEstructuras = (struct miEstructura*) malloc(MAX_ELEM*sizeof(struct miEstructura));
 
 //Rellenamos con numeros aleatorios
 printf("\nVector original: ");
 for (i = 0; i < MAX_ELEM; i++)
 {
   //v[i] = rand()%10000;
   v[i]=MAX_ELEM-i;
   vEstructuras[i].campo=v[i];
   printf("\n\tv[%d]:%d\tvEstructuras[%d]:%d", i, v[i], i, vEstructuras[i].campo);
 }

 //Llamada al quicksort
 //Hacemos un casting con v para indicar el tipo del vector
 
 //Ordenaci�n de un vector de enteros
 qsort((int*)v, MAX_ELEM, sizeof(int), &comparaEnteros);
 
 //Ordenaci�n de un vector de estructuras
 qsort((struct miEstructura*)vEstructuras, MAX_ELEM, sizeof(struct miEstructura), &comparaEstructuras); 
 
 printf("\nVector ordenado: ");
 
 for (i = 0; i < MAX_ELEM; i++)
 {
   printf("\n\tv[%d]:%d\tvEstructuras[%d]:%d", i, v[i],i, vEstructuras[i].campo);
 }
 
 //Busca el numero 8 en el vector
 posicion = (int*)bsearch((int*)&intAux, (int*)v, MAX_ELEM, sizeof(int), &comparaEnteros);
 printf("\nEl elemento %d esta en la posicion %d", intAux, posicion-v );
 
 //Busca el n�mero 9 en el vector de estructuras
 posicionEstr = (struct miEstructura*)bsearch((struct miEstructura*)&estrAux, (struct miEstructura*)vEstructuras, MAX_ELEM, sizeof(struct miEstructura), &comparaEstructuras);
 printf("\nEl elemento %d esta en la posicion %d", estrAux.campo, posicionEstr-vEstructuras); 
} 

/********************************************************************/
/*
Funci�n qsort ANSI C
void qsort(void *base, size_t nmemb, size_t tamanyo,
   int (*comparar)(const void *, const void *));
Ordena un array de nmemb objetos. El elemento inicial es apuntado por base. El tama�o de cada elemento del array est� especificado por tamanyo. El contenido del array es ordenado en el orden de ascienso seg�n una funci�n de comparaci�n apuntada por comparar, la cual es llamada con dos argumentos que apuntan a los objetos a ser comparados. La funci�n retornar� un entero menor, igual, o mayor que cero si el primer objeto es considerado, respectivamente a ser menor, igual, o mayor que el segundo. Si los dos elementos son iguales, su orden en el array ordenado no est� definido.

Valor de retorno:
La funci�n qsort no retorna ning�n valor. 


*/
/********************************************************************/
/*
Funci�n bsearch ANSI C
void *bsearch(const void *clave, const void *base,
   size_t nmemb, size_t tamanyo, 
   int (*comparar)(const void *, const void *));
Busca un array de nmemb objetos, el elemento inicial del que es apuntado por base, para un elemento que empareje el objeto apuntado por clave. El tama�o de cada elemento del array est� especificado por tamanyo. La funci�n de la comparaci�n apuntada por comparar es llamada con dos argumentos que apuntan al objeto clave y a un elemento del array, en ese orden. La funci�n retornar� un entero menor, igual, o mayor que cero si el objeto clave es considerado, respectivamente a ser menor, igual, o mayor que el elemento del array. El array consistir� de: todos los elementos que comparan a ser menores, iguales, o mayores que el objeto clave, en ese orden.

Valor de retorno:
La funci�n bsearch retorna un puntero a un elemento emparejado del array, o a un puntero nulo si ninguna pareja es encontrada. Si dos elementos comparados son iguales, el elemento emparejado no es especificado.


*/
/********************************************************************/
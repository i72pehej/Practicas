#include <stdio.h>
int mayor(int a, int b);
int menor(int a, int b);

int main()
{
   int (*orden) (int, int); //Puntero a funcion
   int ord;
   int a=7, b=2;
   
   printf("Que orden vas a seguir: \n");
   printf("0 Ascendente\n");
   printf("1 Descendente\n");
   scanf("%d",&ord);

   if (ord==0)
      orden=&menor;
   else
      orden=&mayor;
   
   printf("El elemento que va primero es %d\n",(*orden)(a,b));
   printf("El mayor es %d\n", mayor(a,b));
}

int mayor(int a, int b)
{
   if (a>b)
      return a;
   else
     return b;
}

int menor(int a, int b)
{
   if (a<b)
      return a;
   else
      return b;
}

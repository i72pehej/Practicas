#include <stdio.h>
#include <stdlib.h>

int mayor(int a, int b);
int menor(int a, int b);
typedef int (*t_orden) (int, int);

int main()
{
   t_orden * V;
   
   V=(t_orden *) malloc (7*sizeof(t_orden));
   
    int a=7, b=2;
   int ord;
   
   printf("Que orden vas a seguir: \n");
   printf("0 Ascendente\n");
   printf("1 Descendente\n");
   scanf("%d",&ord);

  V[0]=&menor;
  V[1]=&mayor;
   
    if (ord==0)
       printf("El elemento que va primero es %d\n", (*V[0])(a,b));
   else
       printf("El elemento que va primero es %d\n", (*V[1])(a,b));  
   
}  

int mayor(int a, int b)
{
   if (a>b)
      return a;
   else
     return b;
}

int menor(int a, int b)
{
   if (a<b)
      return a;
   else
      return b;
}

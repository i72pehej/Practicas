/*------------------------------------------------------------------*/
/* EJEMPLO DE PUNTEROS A FUNCIONES EN C                             */
/*------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "orden.h"
#define MAX_ELE 15

/*******************************************************************/
/*
   Nombre: pasa_cadena_a_minuscula.
   Tipo: char*.
   Objetivo: Pasa una cadena de caracteres a caracteres en mayuscula	     
   Parametros de entrada:
      -cadena: la cadena de caracteres
   Precondiciones: Ninguna.
   Fecha de creaci�n: 16-05-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
char* pasa_cadena_a_minuscula(char* cadena);
/*******************************************************************/
/*
   Nombre: test_parametros.
   Tipo: voir.
   Objetivo: realiza un test de los parametros de entrada:
      -int argc: numero de parametros
      -char**: vector de cadenas de caracteres con los parametros
   Precondiciones: Ninguna.
   Fecha de creaci�n: 16-05-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void test_parametros(int argc,char** argv);
void generaAleatorios(int* V, int nElementos);
void pintaVector(int* V, int nElementos);

/*******************************************************************/
/*                     FUNCION PRINCIPAL                           */
/*******************************************************************/

void main(int argc,char** argv)
{

   char* metodo, *orden;
   int* V;
   
   test_parametros(argc,argv);
   
   metodo  = argv[1];
   orden   = argv[2];
   
   //Reserva de memoria para un vector de 15 enteros
   if((V = (int*) malloc(MAX_ELE*sizeof(int)))==NULL)
   {
     printf("Error: No es posible reservar memoria para el vector\n");
     exit(-1);
   }
   
   generaAleatorios(V, MAX_ELE);
   
   printf("\nEl vector sin ordenar es: \n");
   printf("----------------------------\n");
   pintaVector(V, MAX_ELE);
   
   if ((strcmp(metodo,"burbuja")==0) && (strcmp(orden,"a")==0))
         burbuja(V, 0 ,MAX_ELE-1, &es_mayor);
   
   if ((strcmp(metodo,"burbuja")==0) && (strcmp(orden,"d")==0))
         burbuja(V, 0 ,MAX_ELE-1, &es_menor);
   
   if ((strcmp(metodo,"seleccion")==0) && (strcmp(orden,"d")==0))
         seleccion(V, 0 ,MAX_ELE-1, &es_mayor);
   
   if ((strcmp(metodo,"seleccion")==0) && (strcmp(orden,"a")==0))
         seleccion(V, 0 ,MAX_ELE-1, &es_menor);
   
   printf("\nEl vector ordenado es: \n");
   printf("----------------------------\n");
   pintaVector(V, MAX_ELE);
   
   //Liberamos la memoria reservada al vector
   //No olvidarse de esto!!!!
   free(V);
   
}

/*******************************************************************/
void generaAleatorios(int* V, int nElementos)
{
   time_t t;
   int i;

   /*inicializamos la semilla*/
   srand((unsigned) time(&t));
   for (i=0; i< nElementos; i++)
   {
     //aleatorio entre 1 y 100
     V[i]=rand() % 101;     
   }  

}
/*******************************************************************/
void pintaVector(int* V, int nElementos)
{
   int i;
   
   for(i=0; i<nElementos; i++)
   {
     printf("\tV[%d]: %d\n", i,V[i]);
   }	
}
/*******************************************************************/

char* pasa_cadena_a_minuscula(char* cadena)
{
        int i;
        for(i=0; cadena[i]!='\0';i++)
        {
                cadena[i]=tolower(cadena[i]);
        }
        cadena[i+1]='\0';
        return(cadena);

}
/*******************************************************************/
void test_parametros(int argc,char** argv)
{
   int error = 0;
   
   if (argc!=3)
   {  
     error = 1;     
   }
   else
   {
     argv[1]=pasa_cadena_a_minuscula(argv[1]);
     if (strcmp(argv[1], "burbuja")!=0)
        if(strcmp(argv[1], "seleccion")!=0)
           error = 1;
     
     argv[2]=pasa_cadena_a_minuscula(argv[2]);
     if (strcmp(argv[2],"a")!=0)
        if(strcmp(argv[2],"d")!=0)
          error=1;
   }       
         
   if(error)
   {
     printf("Error de sintaxis. \n");
     printf("La sintaxis correcta es: \n");
     printf("\tordena <burbuja|seleccion> <a|d>\n");      
     exit(-1);
   } 
}



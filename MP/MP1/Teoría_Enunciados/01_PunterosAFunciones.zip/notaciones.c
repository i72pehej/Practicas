#include <stdio.h>
int suma(int, int);
int funcion(int, int, int (*ptrf)(int, int));

main()
{
	int (*ptrf)(int, int);
	int (*ptrV[1])(int, int);
	
	int res;
	
	ptrf=&suma;
	//ptrf=suma;
	
	res = (*ptrf)(1,2);
	//res =  ptrf(1,2);
    printf("\nRes: %d", res);

    //res=funcion(3,4, &suma);
	//res=funcion(3,4, suma);
    //res=funcion(3,4, ptrf);
	res=funcion(3,4, *ptrf);
	printf("\nRes: %d", res);
	
	//ptrV[0]=&suma;
	ptrV[0]=suma;
	//res=ptrV[0](5,6);
	res=(*ptrV[0])(5,6);
	printf("\nRes: %d", res);
	
}

int suma(int a, int b)
{
	return a+b;
}

int funcion(int a, int b, int (*ptrf)(int, int ))
{
	//return(*ptrf)(a,b);
    return(ptrf(a,b));
}
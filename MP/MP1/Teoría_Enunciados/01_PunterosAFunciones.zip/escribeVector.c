#include <stdio.h>

struct ejemplo
{
   int a;
   float b;
};   

void escribeChar (void *p)
{
 char *caracter = (char *)p;
 printf ("\n%c", *caracter);
}

void escribeInt (void *p)
{
 int *entero = (int *)p;
 printf ("\n%d", *entero);
}

void escribeStruct(void* p)
{
  struct ejemplo * estructura =(struct ejemplo *) p;
  printf("\na: %d  b: %f", estructura->a, estructura->b);
}

void escribeVector (void *p, int n, void (*funcptr)(void *), int tam)
{
 int tipo, i;
 
 for (i=0; i<n; i++)
 {
    (*funcptr)(p+tam*i); 
	//no se puede pasar directamente p[i]
	//porque no se sabe cuanto ocupa cada 
	//elemento
 }
}

int main(void)
{
 char cad[3] = {'a','b','c'};
 int vect[5] = {2,3,4,5,6};
 struct ejemplo estr[2] ={{1, 1.1},{2, 2.2}};
 
 escribeVector ((char*)cad, 3, &escribeChar, sizeof(char));
 escribeVector ((int*)vect, 5, &escribeInt, sizeof(int));
 escribeVector ((struct ejemplo*)estr, 2, &escribeStruct, sizeof(struct ejemplo));
} 

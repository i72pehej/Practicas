#include <stdio.h>
//Prototipos de funciones
double inversos (int k);
double cuadrados (int k);
double funcSuma(int n, double (*f)(int));
int main()
{
   double (*pf)(int);
   
   //A) pasamos el puntero
   pf=&inversos;
   printf("Suma 2 inversos:%lf\n",  funcSuma(2,pf));   
   pf=&cuadrados;
   printf("Suma 3 cuadrados:%lf\n", funcSuma(3,pf));
   
   //B) pasamos la direccion de la funcion
   printf("Suma 4 inversos:%lf\n",  funcSuma(4, &inversos));
   printf("Suma 5 cuadrados:%lf\n", funcSuma(5, &cuadrados));   
   
}
//Definimos la funci�n que recibe el puntero
double funcSuma(int n, double (*f)(int))
{
   double s=0;
   int i;
   for (i=1;i<=n;i++)
      s+=(*f)(i);
   return(s);
}
double inversos (int k)
{
   return 1.0/k;
}
double cuadrados (int k)
{
   return (double)k*k;
}


#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>

void intercambiaInt (void* a, void *b)
{
    int aux, *a_aux, *b_aux;
	
	a_aux = (int*)a;
	b_aux = (int*)b;

    aux = (*a_aux);
	*a_aux = *b_aux;
    *b_aux = aux;
	
}

int comparaInt(void* a, void* b)
{
   int* a_aux, *b_aux;
   
   a_aux = (int*) a;
   b_aux = (int*) b;
   
   if (*a_aux > *b_aux)
     return(-1);
   else
      if (*a_aux==*b_aux) 	 
         return (0);
      else
         return(1);
    
}

void escribeInt (void *p)
{
 int *entero = (int *)p;
 printf ("\n%d", *entero);
}

void * busquedaLineal(void* V, void * clave, int n, int (*comparacion)(void*, void*), int size)
{
   int i;
   void* res=NULL;
   
   for (i=0; i<n; i++)
   {
      if ((*comparacion)(clave, V+i*size)==0)
	  {
	    res = V+i*size;
		return  res;
	  }	
   }
   
   return NULL;

}

void burbuja(void* V, int n, int (*comparacion)(void*, void*), void(*intercambia)(void*, void *), int size)
{
   
   int i, j;   
   int aux;
   
   for(i=1; i<n; i++)
   {
     for(j=n-1; j>=i; j--)
     {
        if((*comparacion)(V+(j-1)*size,V+j*size)<0)
        {
            (*intercambia)(V+(j-1)*size, V+j*size);			
        }
     }
   }   
}


void escribeVector (void *p, int n, void (*funcptr)(void *), int size)
{
 int tipo, i;
 
 for (i=0; i<n; i++)
 {
    (*funcptr)(p+size*i); 
	//no se puede pasar directamente p[i]
	//porque no se sabe cuanto ocupa cada 
	//elemento
 }
}


void main(int argc, char ** argv)
{
   int V[]={1, 9, 4, 6, 2, 5, 3, 7, 8};
   int a=1, b=2, clave;
   int* res;
   
   escribeVector (V, 9, &escribeInt, sizeof(int));
   clave=6;
   res = busquedaLineal((int*)V, (int*)&clave, 9, &comparaInt, sizeof(int));
   printf("\nEl elemento %d esta en posicion: %d valor: %d res:%p", clave, res-V, *res, res);
   
   burbuja((int*)V, 9, &comparaInt, &intercambiaInt, sizeof(int));
   
   escribeVector (V, 9, &escribeInt, sizeof(int));

   
}

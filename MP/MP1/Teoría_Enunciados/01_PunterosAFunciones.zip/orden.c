#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "orden.h"
/*******************************************************************/
/*
   Nombre: burbuja.
   Tipo: void.
   Objetivo: Realiza la ordenaci�n por el metodo de burbuja
                 de un vector de elementos	     
   Parametros de entrada:
      -V: el vector
      -izda, dcha: las posiciones del vector entre las que
                  se desea ordenar
      -comparacion: un puntero a una funcion de comparaci�n
                  que decidir� entre dos datos cual es mayor o menor,
                  dependiendo de que se realice una ordenaci�n ascendente
                  o descendente.
   Precondiciones: Ninguna.
   Fecha de creaci�n: 16-05-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void burbuja(int* V, int izda, int dcha, int(*comparacion)(int, int))
{
   
   int i, j, aux;   
     
   for(i=izda+1; i<=dcha; i++)
   {
     for(j=dcha; j>=i; j--)
     {
        if((*comparacion)(V[j-1],V[j]))
        {
          aux=V[j];
          V[j]=V[j-1];
          V[j-1]=aux;
        }
     }
   }   
}
/*******************************************************************/
/*
   Nombre: seleccion.
   Tipo: void.
   Objetivo: Realiza la ordenaci�n por el metodo de seleccion
                 de un vector de elementos	     
   Parametros de entrada:
      -V: el vector
      -izda, dcha: las posiciones del vector entre las que
                  se desea ordenar
      -comparacion: un puntero a una funcion de comparaci�n
                  que decidir� entre dos datos cual es mayor o menor,
                  dependiendo de que se realice una ordenaci�n ascendente
                  o descendente.
   Precondiciones: Ninguna.
   Fecha de creaci�n: 16-05-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void seleccion(int* V, int izda, int dcha, int(*comparacion)(int, int))
{
   int i, j, pos_menor;
   int menor;
   
   for(i=izda; i<dcha;i++)
   {
      pos_menor = i;
      menor=*(V+i); //menor=V[i];
      
      for(j=i+1; j<=dcha; j++)
      {
      	if((*comparacion)(V[j],menor))
      	{
      	   pos_menor = j;
      	   menor = *(V+j); //V[j]
      	}
      }//for j
      *(V+pos_menor) = *(V+i); //V[pos_menor]=V[i]
      *(V+i)=menor; //V[i]=menor
   }//for i
}

/*******************************************************************/
/*
   Nombre: es_mayor.
   Tipo: int.
   Objetivo: Compara dos numeros enteros y decide si el
             primero que se le pasa como parametro es estrictamente
             mayor que el segundo.	     
   Parametros de entrada:
      - -a y b: punteros a los enteros que se van a comparar.
   Precondiciones: Ninguna.
   Devuelve:
      -si a>b devuelve 1
      -si a<=b devuelve 0
   Fecha de creaci�n: 16-05-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/

int es_mayor(int a, int b)

{
   if( a > b )
   return(1);
   else
   return(0);
}
/*******************************************************************/
/*
   Nombre: es_menor.
   Tipo: int.
   Objetivo: Compara dos numeros enteros y decide si el
             primero que se le pasa como parametro es estrictamente
             menor que el segundo.	     
   Parametros de entrada:
      - -a y b: punteros a los enteros que se van a comparar.
   Precondiciones: Ninguna.
   Devuelve:
      -si a<b devuelve 1
      -si a>=b devuelve 0
   Fecha de creaci�n: 16-05-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int es_menor(int a, int b)
{
   
   if ( a < b )
   return(1);
   else
   return(0);   
}

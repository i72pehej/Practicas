#include "colas.h"
#include <stdlib.h>

/*INSERCIONES AL FINAL Y BORRADOS AL PRINCIPIO*/

void insertarCola(struct cola **cabeza, struct punto p)
{

 struct cola *nuevo = NULL;
 struct cola *aux = NULL;

 /* se reserva espacio para el nuevo elemento */
 nuevo = nuevoElemento();
 nuevo->p = p;
 nuevo->sig = NULL;

 if (*cabeza == NULL) /* la lista est� vacia y el nuevo ser� la cabeza */
  *cabeza = nuevo;
 else /* se localiza el �ltimo elemento para enlazarlo al nuevo */
  {
   aux = *cabeza;
   while(aux->sig != NULL)
   {
    aux = aux->sig;
   }
   aux->sig = nuevo;
  }  
}


struct punto extraerCola(struct cola **cabeza)
{
   struct punto p;
   struct cola *aux;
   
   aux = *cabeza;	
   p = aux->p;
   *cabeza = aux->sig; /* la nueva cabeza es el siguiente */
   free(aux); /* se libera la antigua cabeza */
   return (p);
}

 
 

#include "colas.h"
#include <stdlib.h>

/*INSERCIONES AL PRINCIPIO Y BORRADOS POR EL FINAL*/

void insertarCola(struct cola **cabeza, struct punto p)
{
 struct cola *nuevo = NULL;
 nuevo = nuevoElemento();
 
 nuevo->sig = *cabeza;
 nuevo->p = p;
 *cabeza = nuevo;
}

struct punto extraerCola(struct cola **cabeza)
{
 struct cola *aux = NULL;
 struct cola *ant = NULL;
 struct punto p;
 
 if (((*cabeza)->sig) == NULL) /* Hay un solo elemento */
  {
   p = (*cabeza)->p;
   free(*cabeza);
   *cabeza = NULL;
   return p;  
  }
 else
  {
   aux = *cabeza;
   while(aux->sig != NULL)
   {
      ant = aux;
      aux = aux->sig;
   }
   p = aux->p;
   free(aux); /* se borra el ultimo*/
   ant->sig = NULL;
   return p;
  }
}    


#include <stdio.h>
#include <malloc.h>

struct lista
{
 int n;
 struct lista *sig;
};

int menu();
struct lista *nuevoElemento();
void insertarDelante(struct lista **cabeza, int n);
void imprimirLista(struct lista *cabeza);
void imprimirListaInverso(struct lista *elemento);
int buscarElemento(struct lista *cabeza, int n);
void insertarDetras(struct lista **cabeza, int n);
void borrarElemento(struct lista **cabeza, int n);
void borrarLista(struct lista **elemento);
void borrarListaRecursiva(struct lista **elemento);



void insertarOrden(struct lista **cabeza, int n);

void borrarElementoRecursivo(struct lista **cabeza, int n);
void insertarOrdenRecursivo(struct lista **cabeza, int n);
void ordenarLista(struct lista *cabeza);


main()
{
 int opc, n, encontrado;
 struct lista *cabeza = NULL;
 
 do
  {
   opc = menu();
   switch (opc)
    {
     case 1: /* Insercion al principio */
      printf("Elemento a insertar :");
      scanf("%d", &n);

      /* Comprueba si el elemento ya existe */
      encontrado = buscarElemento(cabeza, n);

      if (!encontrado)
       {
        insertarDelante(&cabeza, n);
	printf("\n Elemento insertado");
       }
      else
       printf("\n Elemento existente");
      printf("\n Pulse intro para seguir"); 
      getchar();
      getchar();        
      break;
     
     case 2: /* Insercion al final */
      printf("Elemento a insertar :");
      scanf("%d", &n);

      /* Comprueba si el elemento ya existe */
      encontrado = buscarElemento(cabeza, n);

      if (!encontrado)
       {
        insertarDetras(&cabeza, n);
	printf("\n Elemento insertado");
       }
      else
       printf("\n Elemento existente");
      printf("\n Pulse intro para seguir");
      getchar();
      getchar();
      break;
      
     case 3: /* recorrido de la lista */
      printf(" Elementos de la lista \n");
      imprimirLista(cabeza);
      printf("\n Pulse intro para seguir");
      getchar();
      getchar();
      break;
           
     case 4: /* Buscar elemento de la lista */
      printf("Elemento a buscar :");
      scanf("%d", &n);

      encontrado = buscarElemento(cabeza, n);

      if (encontrado)
       printf("Elemento encontrado\n");
      else
       printf("Elemento no encontrado \n");
      printf("\n Pulse intro para seguir");
      getchar();
      getchar();
      break;

     case 5: /* Borrado de elemento de la lista */
      printf("Elemento a borrar :");
      scanf("%d", &n);

      /* Comprueba si el elemento est� en la lista */
      encontrado = buscarElemento(cabeza, n);

      if (encontrado)
       {
        borrarElemento(&cabeza, n);
        printf("\n Elemento borrado");
       }
      else
       printf("\n El Elemento no encontrado");
      printf("\n Pulse intro para seguir");
      getchar();
      getchar();
      break;
    
     case 6: /* Insercion en orden */
      printf("Elemento a insertar :");
      scanf("%d", &n);

      /* Comprueba si el elemento ya existe */
      encontrado = buscarElemento(cabeza, n);

      if (!encontrado)
       {
        insertarOrden(&cabeza, n);
	printf("\n Elemento insertado");
       }
      else
       printf("\n Elemento existente");
      printf("\n Pulse intro para seguir");
      getchar();
      getchar();        
      break;

     case 7: /* recorrido de la lista en orden inverso*/
      printf(" Elementos de la lista en orden inverso\n");
      imprimirListaInverso(cabeza);
      printf("\n Pulse intro para seguir");
      getchar();
      getchar();
      break;
           
     case 8: /* borrado de la lista*/
      borrarLista(&cabeza);
      cabeza = NULL;
      printf("Lista borrada \n");
      printf("\n Pulse intro para seguir");
      getchar();
      getchar();
      break;

    case 9: /* Borrado  recursivo de elemento de la lista */
      printf("Elemento a borrar :");
      scanf("%d", &n);

      /* Comprueba si el elemento est� en la lista */
      encontrado = buscarElemento(cabeza, n);

      if (encontrado)
       {
        borrarElementoRecursivo(&cabeza, n);
        printf("\n Elemento borrado");
       }
      else
       printf("\n El Elemento no encontrado");
      printf("\n Pulse intro para seguir");
      getchar();
      getchar();
      break;
      
     case 10: /* Insercion en orden recursivo*/
      printf("Elemento a insertar :");
      scanf("%d", &n);

      /* Comprueba si el elemento ya existe */
      encontrado = buscarElemento(cabeza, n);

      if (!encontrado)
       {
        insertarOrdenRecursivo(&cabeza, n);
	printf("\n Elemento insertado");
       }
      else
       printf("\n Elemento existente");
      printf("\n Pulse intro para seguir");
      getchar();
      getchar();        
      break;
     case 11:
      ordenarLista(cabeza);
      break;      
  }      
 } while (opc != 0);
}


int menu()
{
 int opcion;
 
 //system("clear");
 printf(" \n OPERACIONES SOBRE LISTAS \n");
 printf("\n  1. Insertar por el principio. ");   
 printf("\n  2. Insertar por el final. "); 
 printf("\n  3. Recorrer lista. ");
 printf("\n  4. Buscar elemento en la lista. "); 
 printf("\n  5. Borrar elemento de la lista. ");
 printf("\n  6. Insertar en orden. ");
 printf("\n  7. Recorrido inverso de la lista. ");
 printf("\n  8. Borrado completo de la lista. ");
 printf("\n  9. Borrado recursivo de un elemento. ");
 printf("\n 10. Insertar en orden recursivamente. ");
 printf("\n 11. Ordenar lista por metodo seleccion. ");
 printf("\n  0. Salir. ");
 printf("\n \n    Introduzca una opcion :");
 scanf("%d", &opcion);
 
 return opcion;
} 


struct lista *nuevoElemento()
{
 return ((struct lista *)malloc(sizeof(struct lista)));
}

void insertarDelante(struct lista **cabeza, int n)
{
 struct lista *nuevo = NULL;
 
 /* Se reseva espacio para el nuevo elemento */
 nuevo = nuevoElemento();
 nuevo->n = n;

/* El nuevo elemento se enlaza a la cabeza, y estes ser� la nueva cabeza */
 nuevo->sig = *cabeza;
 *cabeza = nuevo;
}

void imprimirLista(struct lista *cabeza)
{
 struct lista *aux = NULL;
 
 aux = cabeza;
 while (aux != NULL)
  {
   printf(" %d \n", aux->n);
   aux = aux->sig;
  }
}

int buscarElemento(struct lista *cabeza, int n)
{
 int encontrado = 0;
 struct lista *aux = NULL;
 
 aux = cabeza;
 /* Se recorre la lista hasta encontrar el elemento o hasta llegar al final */
 while (aux != NULL && encontrado ==0)
  {
   if (aux->n == n)
    encontrado = 1;
   else
    aux = aux->sig;
  }
 return encontrado;
}

void imprimirListaInverso(struct lista *elemento)
{
	
 if (elemento != NULL)
  {
   imprimirListaInverso(elemento->sig);
   printf(" %d \n", elemento->n);
  }
}

void insertarDetras(struct lista **cabeza, int n)
{
 struct lista *nuevo = NULL;
 struct lista *aux = NULL;

 /* se reserva espacio para el nuevo elemento */
 nuevo = nuevoElemento();
 nuevo->n = n;
 nuevo->sig = NULL;

 if (*cabeza == NULL) /* la lista est� vacia y el nuevo ser� la cabeza */
  *cabeza = nuevo;
 else /* se localiza el �ltimo elemento para enlazarlo al nuevo */
  {
   aux = *cabeza;
   while(aux->sig != NULL)
   {
    aux = aux->sig;
   }
   aux->sig = nuevo;
  }  
}


void borrarElemento(struct lista **cabeza, int n)
{
 struct lista *ant = NULL; /* almacena el elemento anterior al que se borra*/ 
 struct lista *aux = NULL; /* almacena el elemento a borrar */
 
 aux = *cabeza;
 /* Busqueda del elemento a borrar y su anterior */
 while (aux->n != n)
  {
   ant = aux;
   aux = aux->sig;
  }
  
 if (aux == *cabeza) /* el elemento a borrar es la cabeza */
  {
   *cabeza = aux->sig; /* la nueva cabeza es el siguiente */
   free(aux); /* se libera la antigua cabeza */
  }
 else /* El elemento a borrar no es la cabeza */
  {
   ant->sig = aux->sig; /* Se enlaza el anterior con el siguiente */
   free(aux); /* se libera el nodo a borrar */
  }
}

void borrarLista(struct lista **cabeza)
{
   struct lista * aux, * sig;
   aux=*cabeza;
   while(aux!=NULL)
   {
     sig=aux->sig;
     free(aux);
     aux=sig;
   }
   *cabeza=NULL;
}


void borrarListaRecursiva(struct lista **elemento)
{	 
 if (*elemento != NULL)
  {
   borrarListaRecursiva(&((*elemento)->sig));
   free(*elemento);
   *elemento=NULL; //Fin de lista   
  }
}













void insertarOrden(struct lista **cabeza, int n)
{
 struct lista *ant = NULL; /* almacena elemento anterior al que se inserta*/ 
 struct lista *aux = NULL; /* almacena elemento posterior al que se inserta*/
 struct lista *nuevo = NULL; /* almacena el nuevo elemento */
 int encontrado = 0; /* indica que se ha encontrado posici�n de inserci�n */

 /* Se reserva espacio para el nuevo elemento */
 nuevo = nuevoElemento();
 nuevo->n = n;
 
 /* lista vac�a o el elemento se inserta delante de la cabeza*/
 if((*cabeza == NULL) || (*cabeza)->n > n)
 {
    nuevo->sig = *cabeza;
    *cabeza = nuevo; /* la cabeza ser� el nuevo elemento */   
 }
 /* lista no vac�a o el elemento se inserta en una posicion diferente al principio de la lista*/
 else
 {
    /* busqueda de la posicion de insercion, se interrumpe 
           cuando se encuentra el primer elemento mayor que n o cuando
	   se llega al final de la lista*/    
    aux = *cabeza;
	while (aux != NULL && encontrado == 0)
    {
       if (aux->n > n) /* se ha encontrado la posicion de insercion */
          encontrado = 1;
       else /* se actualizan los valores de aux y ant */
        {
	      ant = aux;
	      aux = aux->sig;
	    }
    }
    /* ahora ubicamos el elemento nuevo entre ant y aux, estas acciones
        son v�lidas aunque aux sea igual a NULL */ 
    nuevo->sig = aux;
    ant->sig = nuevo;
 }  
}

void borrarElementoRecursivo(struct lista **cabeza, int n)
{

 struct lista *aux = NULL; /* almacena el elemento a borrar */

 if ((*cabeza)->n != n)
  {
    borrarElementoRecursivo( &((*cabeza)->sig), n);
  }
 else
  {
   aux = *cabeza;
   *cabeza = aux->sig;
   free (aux);   
  }  
}
 
void insertarOrdenRecursivo(struct lista **cabeza, int n)
{ 
 struct lista *nuevo = NULL; /* almacena el nuevo elemento */
 if (*cabeza == NULL) /* Lista vacia o elemento mayor que todos */
  {
   nuevo = nuevoElemento();
   nuevo->n = n;
   nuevo->sig = NULL;
   (*cabeza) = nuevo;
  }
 else
  {
   if ((*cabeza)->n > n)
    {
     nuevo = nuevoElemento();
     nuevo->n = n;
     nuevo->sig = (*cabeza);
     *cabeza = nuevo;
    }
   else
    {
     insertarOrdenRecursivo( &((*cabeza)->sig), n);
    }
  }
}

void ordenarLista(struct lista *cabeza)
{
 struct lista *aux;
 struct lista *aux1;
 struct lista *minimo;
 int numero;
 aux = cabeza;
 while(aux->sig != NULL)
  {
   aux1 = aux->sig;
   minimo = aux;
   while(aux1 != NULL)
    {
     if (aux1->n < minimo->n)
      {
       minimo = aux1;
      }
     aux1 = aux1->sig;
    }
   numero = minimo->n;
   minimo->n = aux->n;
   aux->n = numero;
   aux = aux->sig;
  }
}
   
      
    
      




   
        


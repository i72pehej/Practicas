#include "colas.h"
#include <stdio.h>
#include <stdlib.h>

int menu();

main()
{
 struct cola *cabeza=NULL;
 struct punto p;
 int opc;
 int contieneElementos;
 int nNodos;
 
 do
 {
  opc = menu();
  switch (opc)
  {
   case 1: /* Insertar en cola */       
	printf("\n Inserte elemento");
	p = leerElemento();
    insertarCola(&cabeza, p);
    printf("\n Elemento insertado");
    break;
   
    case 2: /* Extraer de cola */
    contieneElementos = contiene(cabeza);
    if (contieneElementos)
     {
      p = extraerCola(&cabeza);
      printf("\n El elemento extraido es:");
      escribirElemento(p);
     }
    else
     printf("\n Cola Vacia");    
    break;        
    
    case 3: /* Comprobar si hay elementos */
    contieneElementos = contiene(cabeza);   
    if (contieneElementos)
     printf("\n La cola tiene elemntos");
    else
     printf("\n Cola Vacia");
    break;
	
    case 4: /* contar numero de elementos */
    nNodos = contarNodos(&cabeza);       
    printf("\n La cola tiene %d elementos", nNodos);
    break;     
  }
  printf("\n Pulse intro");
  getchar();
  
  
 }while (opc != 0);
}

struct punto leerElemento()
{
	struct punto elemento;
	printf("\n Coordenada x: ");
	scanf("%f", &elemento.x);
	printf("\n Coordenada y: ");
	scanf("%f", &elemento.y);
	return(elemento);
}

void escribirElemento(struct punto elemento)
{
	printf("\n Coordenada x: %f", elemento.x);	
	printf("\n Coordenada y: %f", elemento.y);	
}

int menu()
{
 int opc;
 
 printf("\n 1. Introducir elemento");
 printf("\n 2. Extraer elemento");
 printf("\n 3. Comprobar si cola vacia");
 printf("\n 4. Contar elementos en la cola");
 printf("\n 0. Salir");
 printf("\n \n Introduzca una opcion: ");
 scanf("%d", &opc);
 getchar();
 return opc;
} 
struct cola *nuevoElemento()
{
 return ((struct cola *)malloc(sizeof(struct cola)));
}


int contiene(struct cola *cabeza)
{
 if (cabeza == NULL)
  return 0;
 return 1;
}


int contarNodos(struct cola** cabeza)
{	int nodos = 0;
	struct punto p;
	struct cola* colaAux = NULL;
	
	while(contiene(*cabeza))
	{
	   p=extraerCola(cabeza);
	   insertarCola(&colaAux, p);	
      nodos++;
	}
   *cabeza = colaAux;
	return nodos;
}


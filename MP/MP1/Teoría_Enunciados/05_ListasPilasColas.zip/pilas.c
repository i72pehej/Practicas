#include <stdio.h>
#include <malloc.h>
#include <string.h>

struct pila
{
 char nombre[20];
 struct pila *sig;
};
int menu();
struct pila * nuevoElemento();
void apilar(struct pila **cabeza, char *nombre);
int vacia(struct pila *cabeza);
void desapilar(struct pila **cabeza, char *nombre);
void verCima(struct pila *cabeza, char *nombre);
int contarNodos(struct pila** cabeza);

main()
{
 struct pila *cabeza = NULL;
 char nombre[20];
 int pilaVacia;
 int opc;
 int nNodos;
 
 do
  {
   opc = menu();
   switch (opc)
   {
    case 1: /* Apilar*/
     getchar();
     printf("\n Introduzca Nombre: ");
     gets(nombre);
     apilar(&cabeza, nombre);
     printf("\n Elemento apilado");
    break;

    case 2: /*Desapilar*/
     pilaVacia = vacia(cabeza);
     if (pilaVacia == 0)
      {
       desapilar(&cabeza, nombre);
       printf("\n El elemento extraido es : <%s>", nombre);
      }
     else
      printf("\n La pila est� vac�a");     
    break;
     
    case 3:
     pilaVacia = vacia(cabeza);
     if (pilaVacia == 0)
      {
       verCima(cabeza, nombre);          
       printf("\n El elemento de la cima es : <%s>", nombre);
      }
     else
      printf("\n La pila est� vac�a");
    break;
     
    case 4:
     pilaVacia = vacia(cabeza);
     if (pilaVacia == 0)
      {          
       printf("\n La pila tiene elementos");
      }
     else
      printf("\n La pila est� vac�a");
    break;   
	 
	case 5:
     nNodos = contarNodos(&cabeza);               
     printf("\n La pila tiene %d elementos", nNodos);
     break;     
   } 
     
   printf("\n Pulse intro");
   getchar();
   
  }while (opc != 0);
}

int menu()
{
 int opc;
 
 printf("\n 1. Apilar");
 printf("\n 2. Desapilar");
 printf("\n 3. Ver cima");
 printf("\n 4. Comprobar si pila vac�a");
 printf("\n 5. Contar el numero de nodos de la pila");
 printf("\n 0. Salir");
 printf("\n \n Introduzca una opcion: ");
 scanf("%d", &opc);
 
 return opc;
} 
 
struct pila * nuevoElemento()
{
 return((struct pila *)malloc(sizeof(struct pila)));
}

void apilar(struct pila **cabeza, char *nombre)
{
 struct pila *nuevo = NULL;
 
 nuevo = nuevoElemento();
 strcpy(nuevo->nombre, nombre);
 
 nuevo->sig = *cabeza;
 *cabeza = nuevo;
}

int vacia(struct pila *cabeza)
{
 if (cabeza ==  NULL)
  return 1;
 return 0;
}

void desapilar(struct pila **cabeza, char *nombre)
{
 struct pila *aux;

 aux = *cabeza;
 strcpy(nombre, (*cabeza)->nombre);
 *cabeza = aux->sig;
 free (aux);
}

void verCima(struct pila *cabeza, char *nombre)
{
 strcpy(nombre, cabeza->nombre);
} 

int contarNodos(struct pila** cabeza)
{  struct pila* pilaAux = NULL; //PILA AUXILIAR VAC�A
   int nodos = 0;
   char nombre[20];   
   
   while(!vacia(*cabeza))
   {
       desapilar(cabeza, nombre);
	   apilar(&pilaAux, nombre);
	   nodos ++;	   
   }   
   while(!vacia(pilaAux))
   {
       desapilar(&pilaAux, nombre);
	   apilar(cabeza, nombre);	   
   }
   return nodos;
}


/*Presupone que la informacion de cada persona ocupa tres lineas, una por campo.
SI se permiten nombres y apellidos compuestos
ej.
1111
antonio jose
gomez
1234.56
2222
francisco 
del monte
1345.65
3333
lucia
lozano
956.8
*/


#include "cabecera.h"
#include <stdio.h>
#include <string.h>


/*******************************************************************/
void verFichero(char* nombreFichero)
{ 
 FILE *pFichero;
 struct DatosPersonales persona;
 char linea[MAX_LINEA];
 /* abre fichero para lectura */
 pFichero = fopen(nombreFichero, "r");
  
 /*Lee datos del fichero hasta que llega al final */
 while (fgets(linea, MAX_LINEA, pFichero)!=NULL)
  { 
    //Procesamos dni
    sscanf(linea, "%ld", &persona.dni);
    
    //Procesamos nombre   
    fgets(linea, MAX_LINEA, pFichero);
    limpiarLinea(linea);
    strcpy(persona.nombre, linea);
    
    //Procesamos apellidos - se admiten espacios en blanco
    fgets(linea, MAX_LINEA, pFichero);
    limpiarLinea(linea);
    strcpy(persona.apellido, linea); 
         
	  //Procesamos salario
    fgets(linea, MAX_LINEA, pFichero);
    sscanf(linea, "%f", &persona.salario);  
    
    escribirDatosPersonales(persona);
  }
 fclose(pFichero);
}

/*******************************************************************/
long contarRegistros(char* nombreFichero)
{ 
 FILE *pFichero;
 long nRegistros=0;
 struct DatosPersonales persona;
 char linea[MAX_LINEA];
 /* Abre fichero para lectura */
 pFichero = fopen(nombreFichero, "r"); 
 /* lee datos del fichero hasta que llega al final */
 while (fgets(linea, MAX_LINEA, pFichero)!=NULL)
  {
    nRegistros++;
  }
 fclose(pFichero);
 return(nRegistros/NUM_CAMPOS);
}

/*******************************************************************/
void anadirRegistro(char* nombreFichero, struct DatosPersonales persona)
{
 FILE *pFichero;
 /* abre el fichero para anadir */ 
 pFichero = fopen(nombreFichero, "a"); 
 
 /* escribe los datos en el fichero */
 fprintf(pFichero, "%ld\n%s\n%s\n%.3f\n", persona.dni, persona.nombre,
         persona.apellido, persona.salario);  
 fclose(pFichero);
}

/*******************************************************************/
struct DatosPersonales registro_i(char *nombreFichero, long i)
{
 FILE *pFichero;
 long j;
 struct DatosPersonales persona;
 char linea[MAX_LINEA];
  
 pFichero = fopen(nombreFichero, "r"); 
 
 for(j=0; j<i-1; j++)
 {
     fgets(linea, MAX_LINEA, pFichero);
     fgets(linea, MAX_LINEA, pFichero);
     fgets(linea, MAX_LINEA, pFichero);     
     fgets(linea, MAX_LINEA, pFichero);
 }

 //Procesamos dni
 fgets(linea, MAX_LINEA, pFichero);
 sscanf(linea, "%ld", &persona.dni);     
  
 //Procesamos nombre
 fgets(linea, MAX_LINEA, pFichero);   
 limpiarLinea(linea);    
 strcpy(persona.nombre, linea);
    
 //Procesamos apellidos - se admiten espacios en blanco
 fgets(linea, MAX_LINEA, pFichero);
 limpiarLinea(linea); 
 strcpy(persona.apellido, linea);  
 
 //Procesamos salario
 fgets(linea, MAX_LINEA, pFichero);
 sscanf(linea, "%f", &persona.salario);   
    
 fclose(pFichero);
 
 /* devuelve el registro leido */
 return persona;
}

/********************************************************************/
int buscarporDni(char *nombreFichero, long dni_buscar, struct DatosPersonales *persona)
{
 FILE *pFichero;
 int encontrado = 0; 
 int cont;
 char linea[MAX_LINEA];
 struct DatosPersonales aux;
 
 /* abre fichero para lectura */ 
 pFichero = fopen(nombreFichero, "r");    
 
 //evaluaci�n en corto circuito
 while (!encontrado && (fgets(linea, MAX_LINEA, pFichero)!=NULL))
  {        
    //Procesamos dni
    sscanf(linea, "%ld", &aux.dni);
    
    //Procesamos nombre
    fgets(linea, MAX_LINEA, pFichero);   
    limpiarLinea(linea);    
    strcpy(aux.nombre, linea);
    
    //Procesamos apellidos - se admiten espacios en blanco
    fgets(linea, MAX_LINEA, pFichero);   
    limpiarLinea(linea); 
    strcpy(aux.apellido, linea);  
     
    //Procesamos el salario
    fgets(linea, MAX_LINEA, pFichero);
    sscanf(linea, "%f", &aux.salario);
      
	  //almacena en persona el registro encontrado     
    if (aux.dni == dni_buscar) /* ha encontrado el registro */
    {
      encontrado = 1;      
      *persona = aux; 
    }   
  }
 
 fclose(pFichero); /* se cierra el fichero */
 return encontrado;
}

/********************************************************************/
int mostrarporNombre(char *nombreFichero, char *auxNombre)
{
 FILE *pFichero;
 struct DatosPersonales persona;
 int encontrado = 0;
 char linea[MAX_LINEA];
 /* abre fichero para lectura */  
 pFichero = fopen(nombreFichero, "r"); 
 
 while (fgets(linea, MAX_LINEA, pFichero)!=NULL)
  {  
    //Procesamos dni
    sscanf(linea, "%ld", &persona.dni);
    
    //Procesamos nombre  
    fgets(linea, MAX_LINEA, pFichero); 
    limpiarLinea(linea);   
    strcpy(persona.nombre, linea);
       
    //Procesamos apellidos - se admiten espacios en blanco
    fgets(linea, MAX_LINEA, pFichero);
    limpiarLinea(linea);
    strcpy(persona.apellido, linea);  
   
    //Procesamos el salario
    fgets(linea, MAX_LINEA, pFichero);
    sscanf(linea, "%f", &persona.salario);
    
    //se ha encontrado un registro con ese nombre
    if (strcmp(persona.nombre, auxNombre) == 0)
    {
        escribirDatosPersonales(persona); /* se escriben sus datos */
		    encontrado = 1;         
    }         
  }

 fclose(pFichero); /* se cierra el fichero */
 return encontrado;
} 
/********************************************************************/ 
int actualizarporDni(char* nombreFichero, long dni_buscar)
{
 FILE *pFichero1, *pFichero2;
 struct DatosPersonales persona;
 char linea[MAX_LINEA];
 int encontrado = 0;
 
 /* Se abre para lectura el fichero original */
 pFichero1 = fopen(nombreFichero, "r");

 /* Fichero temporal para volcar los registros que no se borran */
 pFichero2 = fopen("temporal", "w");
 
 /* Se recorre el fichero original y los registros que no hay que borrar
    se pasan al fichero temporal */
    
 while ((fgets(linea, MAX_LINEA, pFichero1)!=NULL))
  {  
    //Procesamos el dni
    sscanf(linea, "%ld", &persona.dni);
     
    //Procesamos el nombre   
    fgets(linea, MAX_LINEA, pFichero1);
    limpiarLinea(linea);
    strcpy(persona.nombre, linea); 
      
    //Leemos apellidos - se admiten espacios en blanco
    fgets(linea, MAX_LINEA, pFichero1); 
    limpiarLinea(linea);;
    strcpy(persona.apellido, linea);      
       
	  //Leemos el salario
    fgets(linea, MAX_LINEA, pFichero1);
    sscanf(linea, "%f", &persona.salario);
	 
    if (persona.dni == dni_buscar)   
    {
   	   persona = introducirDatosPersonales();
   	   encontrado = 1;
    }
    fprintf(pFichero2, "%ld\n%s\n%s\n%.3f\n", persona.dni, persona.nombre,
           persona.apellido, persona.salario);       
  }     
  /* Se cierran los ficheros */
  fclose(pFichero1);
  fclose(pFichero2);
  
 /* Se borra el fichero original */
 remove(nombreFichero);
 
 /* Se renombra el temporal con el nombre del original */
 rename("temporal", nombreFichero);  
 return(encontrado);  
}       
/********************************************************************/
int borrarporDni(char *nombreFichero, long dni_buscar)
{
 FILE *pFichero1, *pFichero2;
 struct DatosPersonales persona;
 char linea[MAX_LINEA];
 int borrado = 0;
 
 /* Se abre para lectura el fichero original */
 pFichero1 = fopen(nombreFichero, "r");

 /* Fichero temporal para volcar los registros que no se borran */
 pFichero2 = fopen("temporal", "w");
 
 /* Se recorre el fichero original y los registros que no hay que borrar
    se pasan al fichero temporal */
    
  while (fgets(linea, MAX_LINEA, pFichero1)!=NULL)
  {
    //Procesamos dni  
    sscanf(linea, "%ld", &persona.dni);
    
    //Procesamos nombre 
    fgets(linea, MAX_LINEA, pFichero1);
    limpiarLinea(linea);    
    strcpy(persona.nombre, linea);
    
    //Procesamos apellidos - se admiten espacios en blanco
    fgets(linea, MAX_LINEA, pFichero1);
    limpiarLinea(linea);  
    strcpy(persona.apellido, linea);   
    
    //Procesamos salario
    fgets(linea, MAX_LINEA, pFichero1);
    sscanf(linea, "%f", &persona.salario);
    
	  //El registro no contiene dni_buscar  
    if (persona.dni != dni_buscar) 
    fprintf(pFichero2, "%ld\n%s\n%s\n%.3f\n", persona.dni, persona.nombre,
           persona.apellido, persona.salario);       
    else
      borrado = 1;       
  }  
   
  /* Se cierran los ficheros */
  fclose(pFichero1);
  fclose(pFichero2);
  
  /* Se borra el fichero original */
  remove(nombreFichero);
 
  /* Se renombra el temporal con el nombre del original */
  rename("temporal", nombreFichero);  
  return(borrado);  
}

/********************************************************************/
struct DatosPersonales* ficheroAVector(char* nombreFichero, long* nEle)
{
   FILE *pFichero;
   struct DatosPersonales persona, *V;
   long i=0;
   char linea[MAX_LINEA];
   
   *nEle = contarRegistros(nombreFichero);
   V = reservarVector(*nEle);
   pFichero = fopen(nombreFichero, "r");
   
   /*Leemos todo el fichero*/   
   while (fgets(linea, MAX_LINEA, pFichero)!=NULL)
   { 
    //Procesamos dni  
    sscanf(linea, "%ld", &persona.dni);
    
    //Procesamos nombre 
    fgets(linea, MAX_LINEA, pFichero);
    limpiarLinea(linea);    
    strcpy(persona.nombre, linea);
    
    //Procesamos apellidos - se admiten espacios en blanco
    fgets(linea, MAX_LINEA, pFichero);
    limpiarLinea(linea);  
    strcpy(persona.apellido, linea);   
    
    //Procesamos salario
    fgets(linea, MAX_LINEA, pFichero);
    sscanf(linea, "%f", &persona.salario);
	  
    V[i]=persona;
    i++;
   } 
      
   fclose(pFichero);
   return(V);
}	

/********************************************************************/      
void vectorAFichero(char* nombreFichero, struct DatosPersonales* V, long nEle)
{
   FILE* pFichero;
   long i=0;
   
   pFichero = fopen(nombreFichero, "wt");
   for (i=0; i<nEle; i++)
   fprintf(pFichero, "%ld\n%s\n%s\n%.3f\n", V[i].dni, V[i].nombre,
         V[i].apellido, V[i].salario);  
   fclose(pFichero);  
}



 

 
 
        
	
      


 

 
 
 


 
 

#include "cabecera.h"
#include <stdio.h>
#include <string.h>

/********************************************************************/
/*
   Nombre: menu.
   Tipo: Entera.
   Objetivo: Visualizar el menu de las distintas opciones del 
             programa.	     
   Parametros de entrada: Ninguno.
   Precondiciones: Ninguna.
   Valor devuelto: Opcion elegida del menu.
*/
/*******************************************************************/
int menu();

/*******************************************************************/
//main
/*******************************************************************/

int main()
{
  int opcion; /*variable para opciones del menu */
  long auxdni; /*variable auxiliar para buscar por dni*/
  int salir; /*variable auxiliar usada en las operaciones de busqueda */
  int existe; /* variable auxiliar para si existe un fichero */
  int encontrado; /* variable que indica si el registro se ha encontrado */
  char auxNombre[15]; /* variable auxiliar para buscar por nombre */
  struct DatosPersonales persona1;
  FILE *pFichero;
  char nombreFichero[15]; /* variable para el nombre del fichero */
  long nRegistro;
  float incremento;
  
  /* Introduccion del nombre del fichero para trabajar */
  printf(" Nombre del fichero: ");
  scanf("%s",nombreFichero);
  
  /* Menu de opciones del programa  */
  do
   {
     opcion = menu();
      switch (opcion)
      {
       case 1: /* Anadir registros al fichero o crearlo si no existe*/
          persona1 = introducirDatosPersonales();
          /* si el fichero no existe se anade el registro */
	      existe = existeFichero(nombreFichero); /* comprueba si existe el fichero */
	      if (existe == 0) /* el fichero no existe*/
          {
	        /* se anade el regitro ya que seria el primero */
	        anadirRegistro(nombreFichero, persona1);
            printf(" Registro anadido. Pulse intro para seguir \n");
	      }
	      else /* el fichero existe */
	      {
           /* Comprueba si esa persona ha sido introducida antes */
	       /* para no duplicar sus datos */
	       encontrado = buscarporDni(nombreFichero, persona1.dni, &persona1);
	       if (encontrado == 1) /* ya existe el registro y no se anade */
	       {
	         printf(" Registro ya existente. Pulse intro para seguir \n");
	       }
           else /* no existe el registro y se puede anadir */
	       {  
	          anadirRegistro(nombreFichero, persona1);
	          printf(" Registro anadido. Pulse intro para seguir \n");
           }
	     }
	     getchar();
	     break;

	    case 2: /* Visualizar el contenido del fichero completo */
           existe = existeFichero(nombreFichero); 
   	       if (existe == 1) /* el fichero existe */
	       {
             verFichero(nombreFichero); /* muestra los registros del fichero */
	         printf(" Datos leidos. Pulse Intro para continuar \n");
	       }
	       else /* el fichero no existe */
	       {
	          printf(" El fichero no existe. Pulse intro para seguir \n");
	       }
	       getchar();
	       break;
	 
       case 3: /* comprobar si existe un registro con dni dado */
	      existe = existeFichero(nombreFichero); 
	      if (existe == 1) /* el fichero existe */
	      {
	        printf(" Introduzca dni a buscar: ");
	        scanf("%ld", &auxdni);
	        getchar();
            encontrado = buscarporDni(nombreFichero, auxdni, &persona1);
	        if (encontrado) /* se ha encontrado el registro */
	        {  
	           /* se escriben los datos de la persona */
	           escribirDatosPersonales(persona1); 
	           printf(" Registro Encontrado. Pulse Intro para continuar  \n");
            }
	        else /* no se ha encontrado el registro */
	        {
	           printf(" Registro NO encontrado. Pulse Intro para continuar  \n");
	        }
	      }
	      else
	      {
	        printf(" El fichero no existe. Pulse intro para seguir \n");
	      }
	      getchar();
	      break;	  


	   case 4: /* buscar los registros con un determinado nombre */
          existe = existeFichero(nombreFichero); 
	      if (existe == 1) /* el fichero existe */
	      {
   	        printf(" Introduzca nombre a buscar: ");
	        fgets(auxNombre, 15, stdin);
	        limpiarLinea(auxNombre);
            encontrado =mostrarporNombre(nombreFichero, auxNombre);
	        if (encontrado == 0) /* No se ha encontrado ninguno */
	          printf("NO se ha encontrado ningun registro. Pulse intro \n");
	        else
	          printf("SI se ha encontrado. Pulse intro para seguir \n");
	      }
	      else
	      {
	        printf(" El fichero no existe. Pulse intro para seguir \n");
	      }
	      getchar();
	      break;	  
	 
	  case 5: //Contar numero de registros del fichero
	      printf("\nEl numero de registros del fichero es: %d\n", contarRegistros(nombreFichero));
	      printf("\nPulse intro para seguir");
	      getchar();
	      break;

       case 6: //Contar numero de bytes del fichero
          printf("\nEl numero de bytes del fichero es: %d\n", contarBytes(nombreFichero));   	 
   	      printf("\nPulse intro para seguir");
	      getchar();
          break;
          
      case 7: //Ver registro i-esimo
	      printf("\nDime el numero de regristro [1..N] :");
	      scanf("%ld", &nRegistro);
	      getchar();
	      persona1= registro_i(nombreFichero, nRegistro);
	      printf("\nEl registro <%d> es: \n", nRegistro);
	      escribirDatosPersonales(persona1);  
   	      printf("\nPulse intro para seguir");
	      getchar();
	      break;    
  
      
       case 8: //actualizar un registro por dni
	     printf("\nDime el dni de busqueda:");
         scanf("%ld", &auxdni);
         getchar();
	     encontrado = actualizarporDni(nombreFichero, auxdni); 
	     if (encontrado)
	       printf("Registro actualizado.");
	     else
           printf("NO existe el registro.");  
         printf("\nPulse intro para seguir");
         getchar();
         break;  
                         	      
	   case 9: /* borrar un registro dado su dni*/
	     printf("\nDime el dni de busqueda:");
         scanf("%ld", &auxdni);
         getchar();
		 encontrado =  borrarporDni(nombreFichero, auxdni);
	     if (encontrado)
	       printf("Registro borrado.");
	     else
           printf("NO existe el registro.");  
         printf("\nPulse intro para seguir");
         getchar();
	     break;       
		 
		 case 10: /* Incrementar sueldo en todos los registros*/
	     printf("\nDime el incremento:");        
		 scanf("%f", &incremento);
         getchar();
         incrementarSalarios(nombreFichero, incremento);
         printf("Salarios incrementados <%.3f> euros.", incremento);  
         printf("\nPulse intro para seguir");
         getchar();	 
	     break;       
      }  
   } while (opcion != 0);
   
   return(0);
}


/*******************************************************************/
/*******************************************************************/
int menu()

{
 int opcion;
 
 do
 {
   printf("********************************************************\n");  
   printf("** 1.  Anadir registros al fichero. ********************\n");
   printf("** 2.  Ver todos los registros del fichero. ************\n");  
   printf("** 3.  Buscar registro dado un DNI. ********************\n");
   printf("** 4.  Mostrar registros con un determinado nombre. ****\n");
   printf("** 5.  Contar numero de registros del fichero **********\n");
   printf("** 6.  Contar numero de bytes del fichero **************\n");
   printf("** 7.  Ver registro i-esimo ****************************\n");
   printf("** 8.  Actualizar un registro por dni*******************\n");
   printf("** 9.  Borrar un registro dado su dni. *****************\n");
   printf("** 10. Incrementar sueldo en todos los registros. ******\n");
   printf("** 0.  Salir del programa. *****************************\n");
   printf("********************************************************\n");
   printf(" \n Introduzca una opcion: ");
   scanf("%d", &opcion);
 }while((opcion<0)||(opcion>10));
 getchar(); //Limpia buffer
 return opcion;
}






/*------------------------------------------------------------------*/
/* EJEMPLO BASICO DE FICHEROS BINARIOS EN C                         */
/*------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_CLIENTES 100
#define MAX_LINE 256
#define MAX_DNI 10 //9 caracteres+'\0'
#define MAX_NOMBRE 20

struct cliente
{
  char DNI[MAX_DNI];
  int cuenta;  
  char nombre[MAX_NOMBRE];
  float saldo;
};

/********************************************************************/
/*
   Nombre: leeLinea.
   Tipo: int.
   Objetivo: Lee una linea de hasta tope-1 elementos o hasta que se llega a '\n'.
	     
   Parametros de entrada:
      - char* cadena: la cadena donde se lee la linea.
      - int tope: El maximo valor de caracteres que se va a leer
   Precondiciones: Ninguna.
   Devuelve: la longitud de la cadena, incluido el '\0'
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int leeLinea(char* cadena, int tope)
{
   int c, i;   
   for(i=0; (i<tope-1)&&((c=getchar())!='\n'); i++)
   {cadena[i]=c;}
   cadena[i]='\0'; //Quitamos el '\n'
   return(i);
}

/********************************************************************/
/*
   Nombre: leeClientes.
   Tipo: int.
   Objetivo: Lee clientes y los introduce en un vector de clientes.
	     
   Parametros de entrada:
      - struct cliente Clientes[]: Vector de clientes.
      - int* tope: Por referencia. N�mero de elementos v�lidos del vector
   Precondiciones: Ninguna.
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/

void leeClientes(struct cliente Clientes[], int* tope)
{
  int salir = 0;
  char opcion;

  printf("\n\nMODULO DE INTRODUCCION DE CLIENTES");
  printf("\n------------------------------------");
  
  while((!salir)&&(*tope<MAX_CLIENTES))
  {
    printf("\nIntroducir DNI del cliente ('S' para salir): ");
    leeLinea(Clientes[*tope].DNI, MAX_DNI);
    if(strcmp("S", Clientes[*tope].DNI)==0)
    {
      salir=1;
    }
    else
    {        
      printf("\tIntroducir nombre del cliente: ");
      leeLinea(Clientes[*tope].nombre, MAX_NOMBRE);
      printf("\tIntroducir numero de cuenta: ");
      fscanf(stdin,"%d", &(Clientes[*tope].cuenta));
      printf("\tIntroducir saldo: ");
      fscanf(stdin,"%f", &(Clientes[*tope].saldo)); 
      (*tope)++;
      getchar(); //Quita '\n'
    }    
  }    	
}

/********************************************************************/
/*
   Nombre: escribeCliente.
   Tipo: void.
   Objetivo: Escribe un cliente en pantalla.	     
   Parametros de entrada:
      - struct cliente clientelientes[]: El cliente.      
   Precondiciones: Ninguna.
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/

void escribeCliente(struct cliente cliente)
{
   printf("\n\tDNI: %s", cliente.DNI);
   printf("\n\tnombre: %s", cliente.nombre);
   printf("\n\tcuenta: %d", cliente.cuenta);
   printf("\n\tsaldo: %f ", cliente.saldo);	
}
/********************************************************************/
/*
   Nombre: listaVectorClientes.
   Tipo: void.
   Objetivo: visualizar por pantalla los elementos de un vector de clientes.
	     
   Parametros de entrada:
      - struct cliente Clientes[]: Vector de clientes.
      - int tope: N�mero de elementos v�lidos del vector
   Valor devuelto: Ninguno.
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor:
*/
/*******************************************************************/
void listaVectorClientes(struct cliente Clientes[], int tope)
{
  int i;
  
  printf("\n\nMODULO DE LISTADO DE CLIENTES (VECTOR)");
  printf("\n----------------------------------------");
  for(i=0; i<tope;i++)
  {
    printf("\nCliente: %d", i+1);
    escribeCliente(Clientes[i]);
  }   
}

/********************************************************************/
/*
   Nombre: existeFichero.
   Tipo: int.
   Objetivo: Comprueba si un fichero existe.	     
   Parametros de entrada: 
      - char *fichero: Nombre del fichero.
   Precondiciones: Ninguna.
   Valor devuelto: 1 si el fichero existe y 0 si no existe.
   Funciones a las que llama: Ninguna.
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int existeFichero(char* nombreFichero) 
{

  FILE* f;
      
  if((f=fopen(nombreFichero, "r"))!=NULL)
  {
    //El fichero existe. Lo cerramos antes de salir    
    fclose(f);
    return(1);
  }
  else
  {
    return(0);	
  }
}  

/********************************************************************/
/*
   Nombre: listaFicheroClientes.
   Tipo: void.
   Objetivo: visualizar por pantalla los registros de un fichero.
	     
   Parametros de entrada:
      - char *fichero: Nombre del fichero.
   Precondiciones:
      - El fichero ha de existir.
      - No escribe los registros marcados como borrados
   Valor devuelto: Ninguno.
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void listaFicheroClientes(char* nombreFichero)
{
  FILE* f; 
  int cuenta =0;
  struct cliente clienteAux;
  
  printf("\n\nMODULO DE LISTADO DE CLIENTES (FICHERO)");
  printf("\n-----------------------------------------");
 
  //abre el fichero en modo lectura binaria
  if((f=fopen(nombreFichero, "rb"))==NULL)
  {
    fprintf(stderr, "\nNo se puede abrir <%s>", nombreFichero);	
  }
  else
  {
    while(fread(&clienteAux, sizeof(struct cliente), 1, f)==1)
    {
      //Si el registro no est� marcado como borrado, lo escribimos	
      if(strcmp(clienteAux.DNI, "")!=0)  
        escribeCliente(clienteAux);
    }
    fclose(f);	
  }	
}

/********************************************************************/
/*
   Nombre: clientesAFichero.
   Tipo: void.
   Objetivo: Escribe un vector de clientes en un fichero. Si el fichero 
             existe, lo borra.
	     
   Parametros de entrada:
         - char *fichero: Nombre del fichero.
         - struct cliente Clientes[]: el vector de clientes.
         - int tope: el n�mero v�lido de elementos del vector.
   Precondiciones: .         
   Valor devuelto: 
         - 1 si la escritura se realiza con exito
         - 0 si hay problemas con la escritura
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void clientesAFichero(char* nombreFichero, struct cliente Clientes[], int tope)
{
  FILE* f;
  if((f=fopen(nombreFichero, "wb"))==NULL)
  {
    fprintf(stderr, "\nError: no se puede abrir <%s>", nombreFichero);	    
  }
  else
  {
    //Escribe todos los clientes
    fwrite(Clientes, sizeof(struct cliente), tope, f);
    printf("\n\tFichero <%s> salvado a disco", nombreFichero);
    fclose(f);    
  }	
}

/********************************************************************/
/*
   Nombre: addClientes.
   Tipo: void.
   Objetivo: Escribe un vector de clientes en un fichero. Si el fichero existe, a�ade
             el contenido al final.
	     
   Parametros de entrada:
         - char *fichero: Nombre del fichero.
         - struct cliente Clientes[]: el vector de clientes.
         - int tope: el n�mero v�lido de elementos del vector.
   Precondiciones: el fichero debe existir.         
   Valor devuelto: 
         - 1 si la escritura se realiza con exito
         - 0 si hay problemas con la escritura   
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void addClientes(char* nombreFichero, struct cliente Clientes[], int tope)
{
  FILE* f;
  if((f=fopen(nombreFichero, "a+b"))==NULL)
  {
    fprintf(stderr, "\nNo se puede abrir <%s>", nombreFichero);	    
  }
  else
  {
    //Escribe todos los clientes v�lidos del vector
    fwrite(Clientes, sizeof(struct cliente), tope, f);
    fclose(f);	
  }	
}

/********************************************************************/
/*
   Nombre: clientesAVector1.
   Tipo: void.
   Objetivo: Lee un fichero de clientes y lo almacena en un vector.
	     
   Parametros de entrada:
         - char *fichero: Nombre del fichero.
         - struct cliente Clientes[]: el vector de clientes.
         - int* tope: Por referencia. El n�mero v�lido de elementos del vector.
   Precondiciones:
         - el fichero debe existir.
         - esta funci�n pasa al vector todos los registros, aunque esten
           marcados como borrados con el campo dni a "" 
   Valor devuelto: 
         - 1 si la lectura se realiza con exito
         - 0 si hay problemas con la lectura
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void clientesAVector(char* nombreFichero, struct cliente Clientes[], int* tope)
{
  FILE* f;
  if((f=fopen(nombreFichero, "rb"))==NULL)
  {
    fprintf(stderr, "\nNo se puede abrir <%s>", nombreFichero);	    
  }
  else
  {
    //Al ser los vectores est�ticos, como mucho podremos almacenar
    //MAX_CLIENTES                        
    *tope = fread(Clientes, sizeof(struct cliente), MAX_CLIENTES, f);
    fclose(f);	
  }	
}

/********************************************************************/
/*
   Nombre: clientesAVector2.
   Tipo: void.
   Objetivo: Lee un fichero de clientes y lo almacena en un vector.
	     
   Parametros de entrada:
         - char *fichero: Nombre del fichero.
         - struct cliente Clientes[]: el vector de clientes.
         - int* tope: Por referencia. El n�mero v�lido de elementos del vector.
   Precondiciones:
         - el fichero debe existir.
         - esta funci�n NO pasa al vector los registros marcados como borrados
           (con el campo dni a "")
         - Al ser los vectores est�ticos, como mucho podremos almacenar MAX_CLIENTES                        
   Valor devuelto: 
         - 1 si la lectura se realiza con exito
         - 0 si hay problemas con la lectura   
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void clientesAVector2(char* nombreFichero, struct cliente Clientes[], int* tope)
{
  FILE* f;
  int cuenta =0;
  struct cliente clienteAux;
  
  if((f=fopen(nombreFichero, "rb"))==NULL)
  {
    fprintf(stderr, "\nNo se puede abrir <%s>", nombreFichero);	    
  }
  else
  {
    *tope=0;
    //Mientras haya clientes y quede espacio en el vector
    while(((cuenta = fread(&clienteAux, sizeof(struct cliente), 1, f))==1) &&
          (*tope<MAX_CLIENTES))
    {
      //El cliente se pasa al vector si no tiene marca de borrado
      if(strcmp(clienteAux.DNI, "")!=0)
      {
        Clientes[*tope]=clienteAux;
        *tope = *tope+cuenta;
      }
    }
    fclose(f);    
  }	
}

/********************************************************************/
/*
   Nombre: clientesAVector3.
   Tipo: void.
   Objetivo: Lee un fichero de clientes y lo almacena en un vector.
	     
   Parametros de entrada:
         - char *fichero: Nombre del fichero.
         - struct cliente Clientes[]: el vector de clientes.
         - int* tope: Por referencia. El n�mero v�lido de elementos del vector.
   Precondiciones:
         - el fichero debe existir.
         - esta funci�n NO pasa al vector los registros marcados como borrados
           (con el campo dni a "")
         - Al ser los vectores est�ticos, como mucho podremos almacenar MAX_CLIENTES                        
   Valor devuelto: 
         - 1 si la lectura se realiza con exito
         - 0 si hay problemas con la lectura   
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void clientesAVector3(char* nombreFichero, struct cliente Clientes[], int* tope)
{
  FILE* f;
  int cuenta =0;
  struct cliente clienteAux;
  
  if((f=fopen(nombreFichero, "rb"))==NULL)
  {
    fprintf(stderr, "\nNo se puede abrir <%s>", nombreFichero);	    
  }
  else
  {
    *tope=0;
    
    cuenta = fread(&clienteAux, sizeof(struct cliente), 1, f);  
    //Mientras haya clientes y quede espacio en el vector
    while((!feof(f))&&(*tope<MAX_CLIENTES))
    {        
      //El cliente se pasa al vector si no tiene marca de borrado
      if(strcmp(clienteAux.DNI, "")!=0)
      {
        Clientes[*tope]=clienteAux;
        *tope = *tope+cuenta;
      }
      
      //Leemos el siguiente cliente
      cuenta = fread(&clienteAux, sizeof(struct cliente), 1, f);  

    }
    fclose(f);	    
  }	
}
/********************************************************************/
/*
   Nombre: tamanio.
   Tipo: long.
   Objetivo: Devuelve el tama�o en bytes de un fichero de cualquier tipo.
	     
   Parametros de entrada:
         - char *fichero: Nombre del fichero.
   Precondiciones:
         - el fichero debe existir.         
   Valor devuelto: El tama�o del vector.
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/

long tamanio(char* nombreFichero)
{
  FILE* f;
  long tam;
  
  printf("\n\nMODULO DE CALCULO DE TAMANIO DEL FICHERO <%s>", nombreFichero);
  printf("\n-------------------------------------------");  
  //Abrimos el fichero en modo lectura
  if((f=fopen(nombreFichero, "rb"))==NULL)
  {
    fprintf(stderr, "\nError: no puedo abrir el fichero <%s>", nombreFichero);
    exit(-1);
  }
  //Nos posicionamos al final
  if(fseek(f, 0L, SEEK_END))
  {
    fprintf(stderr, "\nError: no puedo usar el fichero <%s>", nombreFichero);
    exit(-1);
  }
  //ftell devuelve el tama�o en bytes desde el inicio hasta la posicion actual
  tam = ftell(f);
  fclose(f);
  return(tam);		
}

/********************************************************************/
/*
   Nombre: verRegistro_i.
   Tipo: struct Cliente.
   Objetivo: Devuelve el registro i-�simo de un fichero de clientes.
	     
   Parametros de entrada:
         - char *fichero: Nombre del fichero.
         - i: n�mero de registro.
   Precondiciones:
         - el fichero debe existir.         
         - la posici�n i-�sima debe existir.
         - Si la posici�n i-�sima tiene la marca de borrado, la muestra
   Valor devuelto:
         - El registro de la posici�n i-�sima.
         - cliAux.DNI=""
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
struct cliente verRegistro_i(char *nombreFichero, int i)
{
 FILE *f;
 struct cliente cliAux;
 strcpy(cliAux.DNI, ""); 
 
 if(i>tamanio(nombreFichero))
   return(cliAux);
 
 //Se abre para lectura el fichero
 f = fopen(nombreFichero, "rb");
 
 //Nos desplazamos al final del registro i-1, desde el principio
 //del fichero con la funcion fseek
 fseek(f, i*sizeof(struct cliente), SEEK_SET);
 
 //Se lee el siguiente registro
 fread(&cliAux,sizeof(struct cliente),1,f);

 fclose(f);
 //devuelve el registro leido
 return cliAux;
} 
/********************************************************************/
/*
   Nombre: listaSaldoSuperior.
   Tipo: void.
   Objetivo: Lista clientes consaldo superior a un umbral.
	     
   Parametros de entrada:
         - char *fichero: Nombre del fichero.
         - saldoTope: el saldo umbral.
   Precondiciones:
         - el fichero debe existir.         
         - no muestra los registros marcados con marca de borrado
   Valor devuelto: 
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void listaSaldoSuperior(char* nombreFichero, float saldoTope)
{
  FILE* f;
  struct cliente cliAux;
  
  if((f=fopen(nombreFichero, "rb"))==NULL)
  {
    fprintf(stderr, "Error: no se puede abrir <%s>", nombreFichero);	
  }
  else
  {  
    printf("\n\nMODULO DE LISTADO DE CLIENTES CON SALDO =>%d", saldoTope);
    printf("\n-------------------------------------------");
    //Leemos uno a uno los registros para comprobar la condicion
    while(fread(&cliAux, sizeof(struct cliente), 1, f)==1)    
    {
      if((cliAux.saldo>=saldoTope)&&(strcmp(cliAux.DNI, "")!=0))
      {escribeCliente(cliAux); }
    }
    fclose(f);	
  }		
}

/********************************************************************/
/*
   Nombre: listaSaldoSuperior2.
   Tipo: void.
   Objetivo: Lista clientes consaldo superior a un umbral.
             Utiliza la funcion eof()
	     
   Parametros de entrada:
         - char *fichero: Nombre del fichero.
         - saldoTope: el saldo umbral.
   Precondiciones:
         - el fichero debe existir.         
         - no muestra los registros marcados con marca de borrado
   Valor devuelto: 
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void listaSaldoSuperior2(char* nombreFichero, float saldoTope)
{ FILE* f;
  struct cliente cliAux;  
  if((f=fopen(nombreFichero, "rb"))==NULL)
  {
    fprintf(stderr, "Error: no se puede abrir <%s>", nombreFichero);
  }
  else
  {  
    printf("\n\nMODULO DE LISTADO DE CLIENTES CON SALDO =>%d", saldoTope);
    //Lectura anticipada
    fread(&cliAux, sizeof(struct cliente), 1, f);    
    
    while(!feof(f))    
    {
      if((cliAux.saldo>=saldoTope)&&(strcmp(cliAux.DNI, "")!=0))
      {escribeCliente(cliAux); }
      //Leemos el siguiente cliente
      fread(&cliAux, sizeof(struct cliente), 1, f);
    }
    
    fclose(f);	
  }		
}

/********************************************************************/
/*
   Nombre: consultaSaldo.
   Tipo: void.
   Objetivo: Consulta el saldo de un cliente por DNI.
	     
   Parametros de entrada:
         - char *fichero: Nombre del fichero.
         - char* dniCliente: el dni del cliente.
   Precondiciones:
         - el fichero debe existir.                 
   Valor devuelto: 
         - 0 si no se encuentra el dniCliente
         - 1 si se encuentra el dniCliente 
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void consultaSaldo(char* nombreFichero, char* dniCliente)
{
  FILE* f;
  struct cliente cliAux;
  int encontrado=0;
  
  if((f=fopen(nombreFichero, "rb"))==NULL)
  {
    fprintf(stderr, "Error: no se puede abrir <%s>", nombreFichero);	
  }
  else
  {  
    printf("\n\nMODULO DE CONSULTA DE SALDO:");
    printf("\n------------------------------");       
       
    //Mientras queden registros y no encontremos el dni
    while((fread(&cliAux, sizeof(struct cliente), 1, f)==1)&&(!encontrado))     
    {
      if(strcmp(cliAux.DNI, dniCliente)==0)
      {
        escribeCliente(cliAux);
        encontrado = 1;        
      }
    }    
    fclose(f);	
    if(!encontrado)
    {
      printf("\nNo existe el cliente: <%s>", dniCliente);      
    }
  }		
}


/********************************************************************/
/*
   Nombre: consultaSaldo2.
   Tipo: void.
   Objetivo: Consulta el saldo de un cliente por DNI.
             Utiliza la funcion eof()
	     
   Parametros de entrada:
         - char *fichero: Nombre del fichero.
         - char* dniCliente: el dni del cliente.
   Precondiciones:
         - el fichero debe existir.                 
   Valor devuelto: 
         - 0 si no se encuentra el dniCliente
         - 1 si se encuentra el dniCliente 
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void consultaSaldo2(char* nombreFichero, char* dniCliente)
{ 
  FILE* f;
  struct cliente cliAux;
  int encontrado=0;  
  if((f=fopen(nombreFichero, "rb"))==NULL)
  {
     fprintf(stderr, "Error: no se puede abrir <%s>", nombreFichero);
  }
  else
  { 
    printf("\n\nMODULO DE CONSULTA DE SALDO:");
    //Lectura anticipada
    fread(&cliAux, sizeof(struct cliente), 1, f);   
    while(!feof(f))     
    {
      if(strcmp(cliAux.DNI, dniCliente)==0)
      {
      	escribeCliente(cliAux);
        encontrado = 1;        
      }
      fread(&cliAux, sizeof(struct cliente), 1, f);
    }    
    fclose(f);	
    if(!encontrado)
    {printf("\nNo existe el cliente: <%s>", dniCliente);}
  }		
}

/********************************************************************/
/*
   Nombre: ModificaSaldo.
   Tipo: void.
   Objetivo: Modifica el saldo de un cliente por DNI.
	     
   Parametros de entrada:
         - char *nombreFichero: Nombre del fichero.
         - char* dniCliente: el dni del cliente.
         - float nuevo saldo: el nuevo saldo
   Precondiciones:
         - el fichero debe existir.         
   Valor devuelto: 
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void modificaSaldo(char* nombreFichero, char* dniCliente, float nuevoSaldo)
{ 
  FILE* f;
  struct cliente cliAux;
  int encontrado=0;    
  if((f=fopen(nombreFichero, "r+b"))==NULL)
  {
    fprintf(stderr, "Error: no se puede abrir <%s>", nombreFichero);
  }
  else
  {
    while((fread(&cliAux, sizeof(struct cliente), 1, f)==1)&&(!encontrado))
    {
      if(strcmp(cliAux.DNI, dniCliente)==0)
      {
      	cliAux.saldo = nuevoSaldo; //Actualizamos registro local
        fseek(f, -(int)sizeof(struct cliente), SEEK_CUR); //Retrocedemos posicion        
        fwrite(&cliAux, sizeof(struct cliente), 1, f); //Escribimos registro actualizado        
        encontrado = 1;
        //La siguiente orden es necesario para que en windows  
        //se actualicen los flags de FILE*
        //En Linux, no es necesario, pero se puede dejar
        //El est�ndar requiere fflush para hacer fread despues de write
        fflush(f);
      }
    }
  }    
  fclose(f);	
  if(!encontrado)
  {printf("\nNo existe el cliente: <%s>", dniCliente);}     
}

/********************************************************************/
/*
   Nombre: ModificaSaldo2.
   Tipo: void.
   Objetivo: Modifica el saldo de un cliente por DNI.
             Utiliza feof()
	     
   Parametros de entrada:
         - char *nombreFichero: Nombre del fichero.
         - char* dniCliente: el dni del cliente.
         - float nuevo saldo: el nuevo saldo
   Precondiciones:
         - el fichero debe existir.         
   Valor devuelto: 
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/

void modificaSaldo2(char* nombreFichero, char* dniCliente, float nuevoSaldo)
{ FILE* f;
  struct cliente cliAux;
  int encontrado=0;    
  if((f=fopen(nombreFichero, "r+b"))==NULL)
  {
    fprintf(stderr, "Error: no se puede abrir <%s>", nombreFichero);
  }
  else
  {  
    //Lectura anticpada
    fread(&cliAux, sizeof(struct cliente), 1, f);
    while(!feof(f)&&(!encontrado))
    {      
      if(strcmp(cliAux.DNI, dniCliente)==0)
      {
        cliAux.saldo = nuevoSaldo;
        fseek(f, -(int)sizeof(struct cliente), SEEK_CUR);        
        fwrite(&cliAux, sizeof(struct cliente), 1, f);        
        //La siguiente orden es necesario para que en windows  
        //se actualicen los flags de FILE*
        //En Linux, no es necesario, pero se puede dejar
        //El est�ndar requiere fflush para hacer fread despues de write
        fflush(f);        
        encontrado = 1;
      }
      fread(&cliAux, sizeof(struct cliente), 1, f);
    }    
    fclose(f);	
    if(!encontrado)
    {printf("\nNo existe el cliente: <%s>", dniCliente);}}
  }

/********************************************************************/
/*
   Nombre: Borrado l�gico.
   Tipo: void.
   Objetivo: Realiza el borrado l�gico de un cliente por dni.Para ello 
             actualizar� el valor del dni a cadena vac�a.
	     
   Parametros de entrada:
         - char *nombreFichero: Nombre del fichero.
         - char* dniCliente: el dni del cliente.
   Precondiciones:
         - el fichero debe existir.         
   Valor devuelto: 
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void borradoLogico(char* nombreFichero, char* dniCliente)
{
  FILE* f;
  struct cliente cliAux;
  int encontrado=0;
  long posAct, posRet;  
 
  if((f=fopen(nombreFichero, "r+b"))==NULL)
  {
    //El modo r+b permite Lectura y Escritura sobreescribiendo
    fprintf(stderr, "\nNo se puede abrir <%s>", nombreFichero);	
  }
  else
  {  
    printf("\n\nMODULO DE BORRADO LOGICO POR DNI:");
    printf("\n-----------------------------------");    
    
    //Mientras queden registros y no se encuentre el DNI
    while((fread(&cliAux, sizeof(struct cliente), 1, f)==1)&&(!encontrado))    
    {      	
      //Comprobamos si el DNI concuerda
      if(strcmp(cliAux.DNI, dniCliente)==0)
      {
      	escribeCliente(cliAux);  
        //Actualizamos el valor del DNI con la marca de borrado ("")
        strcpy(cliAux.DNI,""); //cadena vacia
        printf("\n\tdniNuevo: %s ", cliAux.DNI);
        //Retrocededemos una posici�n
        fseek(f, -(int)sizeof(struct cliente), SEEK_CUR);
        //Sobreescribimos el registro
        fwrite(&cliAux, sizeof(struct cliente), 1, f);        
        encontrado = 1;
        //La siguiente orden es necesario para que en windows  
        //se actualicen los flags de FILE*
        //En Linux, no es necesario, pero se puede dejar
        //El est�ndar requiere fflush para hacer fread despues de write
        fflush(f);        
      }
    }    
    fclose(f);	
    if(!encontrado)
    {
      printf("\nNo existe el cliente: <%s>", dniCliente);     
    }
  }		
}

/********************************************************************/
/*
   Nombre: Borrado l�gico2.
   Tipo: void.
   Objetivo: Realiza el borrado l�gico de un cliente por dni.Para ello 
             actualizar� el valor del dni a cadena vac�a.
	     Utiliza feof()
   Parametros de entrada:
         - char *nombreFichero: Nombre del fichero.
         - char* dniCliente: el dni del cliente.
   Precondiciones:
         - el fichero debe existir.         
   Valor devuelto: 
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void borradoLogico2(char* nombreFichero, char* dniCliente)
{
  FILE* f;
  struct cliente cliAux;
  int encontrado=0;
  long posAct, posRet;  
 
  if((f=fopen(nombreFichero, "r+b"))==NULL)
  {
    //El modo r+b permite Lectura y Escritura sobreescribiendo
    fprintf(stderr, "\nNo se puede abrir <%s>", nombreFichero);	
  }
  else
  {  
    printf("\n\nMODULO DE BORRADO LOGICO POR DNI:");
    printf("\n-----------------------------------");    
    
    fread(&cliAux, sizeof(struct cliente), 1, f);
    //Mientras queden registros y no se encuentre el DNI
    while(!feof(f)&&(!encontrado))    
    {      	
      //Comprobamos si el DNI concuerda
      if(strcmp(cliAux.DNI, dniCliente)==0)
      {
      	escribeCliente(cliAux);  
        //Actualizamos el valor del DNI con la marca de borrado ("")
        strcpy(cliAux.DNI,""); //cadena vacia
        printf("\n\tdniNuevo: %s ", cliAux.DNI);
        //Retrocededemos una posici�n
        fseek(f, -(int)sizeof(struct cliente), SEEK_CUR);
        //Sobreescribimos el registro
        fwrite(&cliAux, sizeof(struct cliente), 1, f);        
        encontrado = 1;        
        //La siguiente orden es necesario para que en windows  
        //se actualicen los flags de FILE*
        //En Linux, no es necesario, pero se puede dejar
        //El est�ndar requiere fflush para hacer fread despues de write
        fflush(f);        
      }
      fread(&cliAux, sizeof(struct cliente), 1, f);
    }    
    fclose(f);	
    if(!encontrado)
    {
      printf("\nNo existe el cliente: <%s>", dniCliente);     
    }
  }		
}
/********************************************************************/
/*
   Nombre: BorradoFisico.
   Tipo: void.
   Objetivo: Realiza el borrado f�sico de todos los clientes con la marca
             de registro borrado.	     
   Parametros de entrada:
         - char *nombreFichero: Nombre del fichero.
   Precondiciones:
         - el fichero debe existir.         
   Valor devuelto: 
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void borradoFisico(char* nombreFichero)
{
  FILE* f;
  FILE* faux;
  struct cliente cliAux;  
  int encontrado=0;
  
  //Abrimos el fichero para lectura y un fichero temporal para escritura
  if(((f=(FILE*)fopen(nombreFichero, "rb"))==NULL)||
     ((faux=(FILE*)fopen("tmp"     , "wb"))==NULL))
  {
    fprintf(stderr, "Error: no se puede abrir <%s> o <aux.tmp>", nombreFichero);	
  }
  else
  {  
    printf("\n\nMODULO DE BORRADO FISICO:");
    printf("\n-----------------------------------");
    
    //Leemos uno a uno el fichero original    
    while(fread(&cliAux, sizeof(struct cliente), 1, f)==1)
    {
      //Si el cliente NO tiene la marca de borrado
      if(strcmp(cliAux.DNI, "")!=0)
      {
        //Lo escribimos en el fichero temporal
        fwrite(&cliAux, sizeof(struct cliente), 1, faux);                                       
      }
      else
      {
        printf("\nBORRADO: %s", cliAux.nombre);
        encontrado=1;          
      }
    }//while  
      
    //Cerramos los dos ficheros
    fclose(f);  
    fclose(faux);	
    
    if(!encontrado)
    { //Si no hay registros para borrar, eliminamos el fichero temporal
      printf("\nNo hay registros para borrar");
      remove("tmp");      
    }
    else
    {
      //Elminamos el fichero antiguo	  
      remove(nombreFichero);
      //Le cambiamos el nombre al temporal, que pasa a ser el fichero actualizado
      rename("tmp", nombreFichero);           	      
    }    
  }//else	
}


/********************************************************************/
/*
   Nombre: menuPrincipal().
   Tipo: int.
   Objetivo: Muestra al usuario el men� principal y lee su opcion.
	     
   Parametros de entrada:
   Precondiciones:
   Valor devuelto: la opci�n del usuario
   Funciones a las que llama:
   Fecha de creaci�n: 6-03-05.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int menuPrincipal()
{
   int opcion;
   do
   {
     printf("\n-----------------");
     printf("\n\nMENU PRINCIPAL");
     printf("\n-----------------\n\n");
     printf("\n1. Introducir clientes (crea fichero)"); 
     printf("\n2. Listar clientes (fichero)");
     printf("\n3. Listar clientes (vector)");  
     printf("\n4. Anadir clientes al fichero");
     printf("\n5. Lista clientes con saldo superior a una cantidad");
     printf("\n6. Consulta el saldo de clientes");
     printf("\n7. Modifica el saldo de clientes"); 
     printf("\n8. Tamano del fichero"); 
     printf("\n9. Borrado Logico de un cliente por DNI");
     printf("\n10 Borrado Fisico");
     printf("\n11 Ver un registro del fichero");        
     printf("\n0. Salir\n\n");   
     scanf("%d", &opcion);
   }while((opcion<0)||(opcion>11));
   
   //Quitamos el '\n' final
   getchar();  
   return(opcion);
   	
}

/*******************************************************************/
/********************** PROGRAMA PRINCIPAL *************************/
/*******************************************************************/
int main()
{
  struct cliente Clientes[MAX_CLIENTES];
  struct cliente cliAux;
  char nombreFichero[MAX_LINE];
  char dniCliente[MAX_DNI];  
  int tope=0, opcion;
  int salir=0, numeroReg;
  long tam; 
  float saldo;
  
  
  //Introduccion del nombre del fichero para trabajar
  printf("\nIndique el nombre del fichero de trabajo: ");
  scanf("%s", nombreFichero);
   
  while(!salir)
  {   
    opcion =menuPrincipal();    
    switch(opcion)
    {
      case 0: salir =1;	
              break;
      case 1: leeClientes(Clientes, &tope);
              clientesAFichero(nombreFichero, Clientes, tope);              
              tope=0;               
              break;
      case 2: listaFicheroClientes(nombreFichero);              
              break;
      case 3: clientesAVector3(nombreFichero,  Clientes, &tope);      
              listaVectorClientes(Clientes, tope);
              break;
      case 4: tope=0;
              leeClientes(Clientes, &tope);   
              addClientes(nombreFichero, Clientes, tope);              
              break;  
      case 5: printf("\nIntroduzca saldo => <cifra>: ");
              scanf("%f", &saldo);
              listaSaldoSuperior2(nombreFichero, saldo);
              break;
      case 6: printf("\nIntroduzca dniCliente: ");
              scanf("%s", dniCliente);
              consultaSaldo2(nombreFichero, dniCliente);                  
              break;
      case 7: printf("\nIntroduzca dniCliente: ");
              scanf("%s", dniCliente);
              printf("\nIntroduzca nuevo saldo: ");
              scanf("%f", &saldo);
              modificaSaldo2(nombreFichero, dniCliente, saldo);
              break;
      case 8: //Tamanio del fichero     
              tam = tamanio(nombreFichero); 
              printf("\nFichero: <%s>  %ld bytes %5.2f Kbytes", nombreFichero, tam, tam/1024.0);
              printf("\n\tContenido: %d registros", tam/sizeof(struct cliente));              
              break;      
      case 9: printf("\nIntroduzca dniCliente: ");
              scanf("%s", dniCliente);      
              borradoLogico2(nombreFichero, dniCliente);
              break;
      case 10:borradoFisico(nombreFichero);
              break;
      case 11://Ver el registro i
              printf("\nEscriba numero de registro [0, nRegistros-1]: ");
              scanf("%d", &numeroReg);
              cliAux = verRegistro_i(nombreFichero,numeroReg);
              if(strcmp(cliAux.DNI, "")!=0)
              {
              	escribeCliente(cliAux);
              }
              else
              {
                printf("\n\tEl registro %d no existe", numeroReg);	
              }  
              break;
    }	
  }  
  return(0);
}

#include <stdio.h>

int main()
{
  char nombre[11] = "getpos.dat",
       mensaje[81]="Esto es nua rpueba usando fgetpos y fsetpos.";
  FILE *fichero;
  fpos_t posicion=0, comienzo;

  fichero = fopen( nombre, "w+" );
  printf( "Fichero: %s -> ", nombre );
  if( fichero )
    printf( "creado (ABIERTO)\n" );
  else
  {
    printf( "Error (NO ABIERTO)\n" );
    return 1;
  }

  fgetpos( fichero, &comienzo );
  printf("Posicion del fichero: %d\n", posicion );
  printf("\tftell: %d\n", ftell(fichero));

  fprintf( fichero, mensaje );
  printf( "\nEscrito: \"%s\"\n", mensaje );

  fgetpos( fichero, &posicion );
  printf( "Posicion del fichero: %d\n", posicion );
  printf("\tftell: %d\n", ftell(fichero));
  
  fsetpos( fichero, &comienzo );
  fprintf( fichero, "%s", "Esto es una prueba" );
  printf( "Corregiendo errores...Escrito: \"Esto es una prueba\"\n" );

  fgetpos( fichero, &posicion );
  printf( "Posicion del fichero: %d\n", posicion );
  printf("\tftell: %d\n", ftell(fichero));

  rewind( fichero );
  printf( "\"Rebobinando\" el fichero -> Vuelta al comienzo\n" );
  fgetpos( fichero, &posicion );
  printf( "Posicion del fichero: %d\n", posicion );
  printf("\tftell: %d\n", ftell(fichero));

  printf( "\nLeyendo del fichero \"%s\"\n", nombre );
  fgets( mensaje, 81, fichero );
  printf( "\"%s\"\n\n", mensaje );

  fgetpos( fichero, &posicion );
  printf( "Posicion del fichero: %d\n", posicion );
  printf("\tftell: %d\n", ftell(fichero));

  if( !fclose(fichero) )
    printf( "Fichero cerrado\n" );
  else
  {
    printf( "Error: fichero NO CERRADO\n" );
    return 1;
  }

  return 0;
}

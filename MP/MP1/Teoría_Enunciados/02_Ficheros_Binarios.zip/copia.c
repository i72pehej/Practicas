//Hace una copia de un fichero
#include <stdio.h>
#define TAM_BUF 1024 //tamanio del buffer en bytes

typedef char byte;
int main()
{
  FILE *fOrigen, *fDestino;
  char nomOrigen[]="origen.doc", nomDestino[]="destino.doc";
  long leidos;
  byte buffer[TAM_BUF]; 
  
  //Abre el fichero origen en modo lectura
  if((fOrigen=fopen(nomOrigen, "rb"))==NULL)
  {
    printf("\nError: no pudeo abrir %s", nomOrigen);
    exit(-1);
  }

  //Abre el fichero destino en modo escritura
  if((fDestino=fopen(nomDestino, "wb"))==NULL)
  {
    printf("\nError: no pudeo crear %s", nomDestino);
    exit(-1);
  }
  
  //En cada iteracion intentamos leer TAM_BUF objetos
  //de 1 byte. Escribimos lo que hemos leido
  //while((leidos=fread(buffer, 1, TAM_BUF, fOrigen))==1)
  //Equivalente a :
  while((leidos=fread(buffer, sizeof(byte), TAM_BUF, fOrigen))>0)
  {
    fwrite(buffer, sizeof(byte), leidos, fDestino);
  }
  
  fclose(fOrigen);
  fclose(fDestino);
  return(0);
}
#include <stdio.h>

int main()
{
  FILE* f;
  long tam;
  char nombre[] = "origen.doc";
  
  if((f=fopen(nombre, "rb"))==NULL)
  {
    fprintf(stderr, "\nError: no puedo abrir el fichero <%s>", nombre);
    exit(-1);
  }
  
  if(fseek(f, 0L, SEEK_END))
  {
    fprintf(stderr, "\nError: no puedo usar el fichero <%s>", nombre);
    exit(-1);
  }
  
  tam = ftell(f);
  printf("\nFichero: <%s>  %ld bytes %5.2f Kbytes", nombre, tam, tam/1024.0);
  fclose(f);	
  return(0);
}

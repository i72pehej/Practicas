//Ejemplo de utilizacion de las funciones rename y remove
#include <stdio.h>

int main()
{
  char nombreFichero[30], nombreNuevo[30];
  int opcion;
  
  printf("\nQue desea hacer?:");
  printf("\n1 Borrar fichero");
  printf("\n2 Renombrar fichero");
  scanf("%d", &opcion);

  switch(opcion)
  {
     case 1: 
           printf("\nIntroduzca el nombre del fichero a borrar: ");
           scanf("%s", nombreFichero);
           if(remove(nombreFichero)!=0)
              printf("\n\tNO se ha podido realizar la operacion");
           else
              printf("\nOperacion realizada con exito");
           break;
     case 2:
           printf("\nIntroduzca el nombre del fichero a renombrar: ");
           scanf("%s", nombreFichero);
           printf("\nIntroduzca el nombre del fichero a renombrar: ");
           scanf("%s", nombreNuevo);
           if(rename(nombreFichero, nombreNuevo)!=0)
              printf("\n\tNO se ha podido realizar la operacion");
           else
              printf("\nOperacion realizada con exito");
           break;
  }
  return(1);	
}



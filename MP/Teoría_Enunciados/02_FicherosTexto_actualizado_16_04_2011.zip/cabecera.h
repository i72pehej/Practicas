
#include "stdio.h"
#include "stdlib.h"

/* Definicion del tipo DatosPersonales */
struct DatosPersonales
{
  char nombre[15];
  char apellido[15];
  long dni;
};

/* prototipos de funciones */
struct DatosPersonales introducirDatosPersonales();
void escribirDatosPersonales(struct DatosPersonales aux);
int existeFichero(char *fichero);
void anadirRegistros(char *fichero);
void verFichero(char *fichero);
int buscarporDni(char *fichero, long dni, struct DatosPersonales *persona);
int buscarporNombre(char *fichero, char *auxnombre);
void borrarporDni(char *fichero, long dni);
long contarBytes(char *fichero);
int contarRegistros(char *fichero);
struct DatosPersonales verRegistro_i(char *fichero, int i);
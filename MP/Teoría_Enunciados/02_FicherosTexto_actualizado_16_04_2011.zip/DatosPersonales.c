
#include "cabecera.h"

/********************************************************************/
/*
   Nombre: menu.
   Tipo: Entera.
   Objetivo: Visualizar el menu de las distintas opciones del 
             programa.
	     
   Parametros de entrada: Ninguno.
   Precondiciones: Ninguna.
   Valor devuelto: Opcion elegida del menu.
   Funciones a las que llama: Ninguna.
   Fecha de creaci�n: 7-01-03.
   Autor:
*/
/*******************************************************************/

int menu()
{
 int opcion;
 
 do
 {
   printf("********************************************************\n");  
   printf("** 1.  Anadir registros al fichero. ********************\n");
   printf("** 2.  Ver todos los registros del fichero. ************\n");
   printf("** 3.  Buscar un registro dado su dni.  ****************\n");
   printf("** 4.  Buscar registros dado su Nombre. ****************\n");
   printf("** 5.  Borrar un registro dado su dni. *****************\n");
   printf("** 6.  Contar numero de registros del fichero **********\n");
   printf("** 7.  Contar numero de bytes del fichero **************\n");
   printf("** 8.  Ver registro i-esimo ****************************\n");
   printf("** 0.  Salir del programa. *****************************\n");
   printf("********************************************************\n");
   printf(" \n Introduzca una opcion: ");
   scanf("%d", &opcion);
 }while((opcion<0)||(opcion>8));
 return opcion;
}

/********************************************************************/
/*
   Nombre: introducirDatosPersonales.
   Tipo: struct DatosPersonales.
   Objetivo: Introducir por teclado los datos de una persona.
	     
   Parametros de entrada: Ninguno.
   Precondiciones: Ninguna.
   Valor devuelto: Datos de una persona.
   Funciones a las que llama: Ninguna.
   Fecha de creaci�n: 7-01-03.
   Autor:   
*/
/*******************************************************************/

struct DatosPersonales introducirDatosPersonales()
{
 struct DatosPersonales aux;

 /*Introduccion de datos */
 printf("  DNI : ");
 scanf("%ld", &aux.dni); 
 getchar();
 printf("Nombre : ");
 scanf("%s",aux.nombre);
 printf("Apellido :");
 scanf("%s",aux.apellido);

 /* devolucion de los datos de la persona */
 return aux;
}

/********************************************************************/
/*
   Nombre: escribirDatosPersonales.
   Tipo: void.
   Objetivo: Visualizar por pantalla los datos de una persona.
	     
   Parametros de entrada: 
      - struct DatosPersonales aux: Datos de una persona.
   Precondiciones: Ninguna.
   Valor devuelto: Ninguno.
   Funciones a las que llama: Ninguna.
   Fecha de creaci�n: 7-01-03.
   Autor:
*/
/*******************************************************************/

void escribirDatosPersonales(struct DatosPersonales aux)
{
 printf("  Nombre: %s  Apellido: %s  DNI: %ld \n",
         aux.nombre, aux.apellido, aux.dni);
}

/********************************************************************/
/*
   Nombre: existeFichero.
   Tipo: int.
   Objetivo: Comprueba si un fichero existe.
	     
   Parametros de entrada: 
      - char *fichero: Nombre del fichero.
   Precondiciones: Ninguna.
   Valor devuelto: 1 si el fichero existe y 0 si no existe.
   Funciones a las que llama: Ninguna.
   Fecha de creaci�n: 7-01-03.
   Autor:
*/
/*******************************************************************/

int existeFichero(char *fichero)
{
 FILE *pFichero;
 
 pFichero = fopen(fichero, "r"); /* abre fichero para lectura */
 if (pFichero == NULL) /* el fichero no existe */
  {
   return 0;
  }
 else /* el fichero existe */
  {
   fclose (pFichero);
   return 1;
  }
}

/********************************************************************/
/*
   Nombre: anadirRegistro.
   Tipo: void.
   Objetivo: a�ade un registro a un fichero.
	     
   Parametros de entrada:
      - char *fichero: Nombre del fichero.
      - struct DatosPersonales persona: Datos del registro a a�adir.
   Precondiciones: Ninguna.
   Valor devuelto: Ninguno.
   Funciones a las que llama: Ninguna.
   Fecha de creaci�n: 7-01-03.
   Autor:
*/
/*******************************************************************/

void anadirRegistro(char *fichero, struct DatosPersonales persona)
{
 FILE *pFichero;
  
 pFichero = fopen(fichero, "a"); /* abre el fichero para anadir */
 fprintf(pFichero, "%s %s %ld\n", persona.nombre, persona.apellido,
	    persona.dni);  /* guarda los datos en el fichero */
 fclose(pFichero);
}

/********************************************************************/
/*
   Nombre: verFichero.
   Tipo: void.
   Objetivo: visualizar por pantalla los registros de un fichero.
	     
   Parametros de entrada:
      - char *fichero: Nombre del fichero.
   Precondiciones: El fichero ha de existir.
   Valor devuelto: Ninguno.
   Funciones a las que llama:
      - escribirDatosPersonales.
   Fecha de creaci�n: 7-01-03.
   Autor:
*/
/*******************************************************************/
 
void verFichero(char *fichero)
{ 
 FILE *pFichero;
 struct DatosPersonales persona;

 pFichero = fopen(fichero, "r"); /* abre fichero paa lectura */
 /* Comienza a leer datos del fichero hasta que llega al final */
 while (fscanf(pFichero, "%s %s %ld", persona.nombre, persona.apellido,
	           &persona.dni)==3)
  {
    escribirDatosPersonales(persona);
  }
 fclose(pFichero);
}


/*******************************************************************/
int contarRegistros(char *fichero)
{ 
 FILE *pFichero;
 int nRegistros=0;
 struct DatosPersonales persona;

 pFichero = fopen(fichero, "r"); /* abre fichero paa lectura */
 /* Comienza a leer datos del fichero hasta que llega al final */
 while (fscanf(pFichero, "%s %s %ld", persona.nombre, persona.apellido,
	           &persona.dni)==3)
  {
    nRegistros++;
  }
 fclose(pFichero);
 return(nRegistros);
}

struct DatosPersonales verRegistro_i(char *fichero, int i)
{
 FILE *pFichero;
 int j;
 struct DatosPersonales persona;
 
 pFichero = fopen(fichero, "r");
 
 for(j=0; (j<i); j++)
 {
    fscanf(pFichero, "%s %s %ld", persona.nombre, persona.apellido, &persona.dni);
 }   
 fclose(pFichero);
 
 /* devuelve el registro leido */
 return persona;

}

/*******************************************************************/
long contarBytes(char *fichero)
{ 
  FILE* f;
  long tam;
  
  if((f=fopen(fichero, "rb"))==NULL)
  {
    fprintf(stderr, "\nError: no puedo abrir <%s>", fichero);exit(-1);
  }  
  if(fseek(f, 0L, SEEK_END))
  {
    fprintf(stderr, "\nError: no puedo usar <%s>", fichero); exit(-1);
  }
  tam = ftell(f);
  fclose(f);	
  return(tam);
}
/********************************************************************/
/*
   Nombre: buscarporDni.
   Tipo: int.
   Objetivo: Busca un registro por su dni.
	     
   Parametros de entrada:
      - char *fichero: Nombre del fichero.
      - long dni: Dni del registro a buscar.
      - struct DatosPersonales *persona: Datos de la persona buscada.
        En caso de que exista el registro, esta variable lo contiene.
   Precondiciones: El fichero ha de existir.
   Valor devuelto: 0 si el registro no se encuentra y 1 si se encuentra.
   Funciones a las que llama: Ninguna.
   Fecha de creaci�n: 7-01-03.
   Autor:
*/
/*******************************************************************/
    
int buscarporDni(char *fichero, long dni, struct DatosPersonales *persona)
{
 FILE *pFichero;
 int salir = 0;
 int encontrado = 0; /* variables auxiliares para la busqueda */
 int cont;
 struct DatosPersonales auxiliar;
 
 pFichero = fopen(fichero, "r"); /* abre fichero para lectura */    
 while (salir == 0)
  {
   cont = fscanf(pFichero, "%s %s %ld", auxiliar.nombre, auxiliar.apellido,
	  &auxiliar.dni);
   if (cont != 3) /* ha llegado al final del fichero */
    salir = 1;
   else 
    if (auxiliar.dni == dni) /* ha encontrado el registro */
     {
      encontrado = 1;
      salir = 1;
      *persona = auxiliar; /* almacena en persona el registro encontrado */
     }
   }
 fclose(pFichero); /* se cierra el fichero */
 return encontrado;
}

/********************************************************************/
/*
   Nombre: buscarporNombre.
   Tipo: int.
   Objetivo: Visualiza todos los registros que tengan un nombre dado
             por el usuario.
	     
   Parametros de entrada:
      - char *fichero: Nombre del fichero.
      - char *auxNombre: Nombre de los registros a visualizar.
   Precondiciones: El fichero ha de existir.
   Valor devuelto: 0 si no se encuentra ning�n registro y 1 si se 
                   encuentra alguno.
   Funciones a las que llama:
      - escribirDatosPersonales.
   Fecha de creaci�n: 7-01-03.
   Autor:
*/
/*******************************************************************/
 
int buscarporNombre(char *fichero, char *auxNombre)
{
 FILE *pFichero;
 struct DatosPersonales auxiliar;
 int encontrado = 0;
 
 pFichero = fopen(fichero, "r"); /* abre fichero para lectura */    
 while (fscanf(pFichero, "%s %s %ld", auxiliar.nombre, auxiliar.apellido,
	  &auxiliar.dni) == 3) /* se leen todos los registros */
  {
   if (strcmp(auxiliar.nombre, auxNombre) == 0)
   /* se ha encontrado un registro con ese nombre */
    {
     escribirDatosPersonales(auxiliar); /* se escriben sus datos */
     encontrado = 1;
    }
  }
 fclose(pFichero); /* se cierra el fichero */
 return encontrado;
} 

/********************************************************************/
/*
   Nombre: borrarporDni.
   Tipo: void.
   Objetivo: borra el registro correspondiente a una persona 
             dado su dni, haciendo un volcado de los registros
	     que no se borran a un fichero auxiliar, y renombrando
	     finalmente el auxiliar con el nombre del fichero
	     original.
	     
   Parametros de entrada: 
      - char *fichero: Nombre del fichero.
      - long dni: dni del registro a borrar.
   Precondiciones: Ha de existir el fichero y el registro a borrar.
   Valor devuelto: Ninguno.
   Funciones a las que llama: Ninguna.
   Fecha de creaci�n: 7-01-03.
   Autor:
*/
/*******************************************************************/

void borrarporDni(char *fichero, long dni)
{
 FILE *pFichero1, *pFichero2;
 struct DatosPersonales aux;
 
 /* Se abre para lectura el fichero original */
 pFichero1 = fopen(fichero, "r");

 /* Fichero temporal para volcar los registros que no se borran */
 pFichero2 = fopen("temporal", "w");
 
 /* Se recorre el fichero original y los registros que no hay que borrar
    se pasan al fichero temporal */
 while(fscanf(pFichero1, "%s %s %ld", 
       aux.nombre, aux.apellido, &aux.dni) == 3)
  {
   if (aux.dni != dni)
    fprintf(pFichero2, "%s %s %ld\n", aux.nombre, aux.apellido, aux.dni);
  }
  
  /* Se cierran los ficheros */
  fclose(pFichero1);
  fclose(pFichero2);
  
 /* Se borra el fichero original */
 remove(fichero);
 
 /* Se renombra el temporal con el nombre del original */
 rename("temporal", fichero);    
}
 
       
	
      


 

 
 
 


 
 

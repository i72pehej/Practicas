//Formatea a doble espacio un fichero
#include <stdio.h>
//----------------------------------------------------------
//Funcion: doblaEspacios
//Tarea: Formatea a doble espaciado un fichero de texto
//Recibe: nombreOrigen ->Nombre del fichero origen
//        nombreDestion->Nombre del fichero destino
//Devuelve (int): 1 si se ha podido efectuar con exito
//                0 en caso contrario
//----------------------------------------------------------
int doblaEspacios(char* nombreOrigen, char* nombreDestino)
{
  FILE* fOrigen, * fDestino;
  int c;
  
  if((fOrigen=(FILE*)fopen(nombreOrigen, "r"))!=NULL)
  {        
    if((fDestino=(FILE*)fopen(nombreDestino, "w"))!=NULL)
    {
       while((c=getc(fOrigen))!=EOF)
       {
          putc(c, fDestino);
          if(c=='\n')
          { //si es '\n' se escribe el '\n' otra vez 
             putc(c, fDestino); 	
          }     
       }     
       fclose(fOrigen);
       fclose(fDestino);
       return(1);
    }
  }
  else
    return 0;
}
//-----------------------------------------------------------
//           PROGRAMA PRINCIPAL
//-----------------------------------------------------------
int main()
{
  FILE* fOrigen, *fDestino;
  char nombreOrigen[]="fichtexto.txt", nombreDestino[]="destino.txt";

  if (!doblaEspacios(nombreOrigen, nombreDestino))
  {
      printf("\nNo se ha podido realizar la operacion");     
  }

  return(0);
}


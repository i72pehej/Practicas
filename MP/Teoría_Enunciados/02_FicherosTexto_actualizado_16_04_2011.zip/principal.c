
/*ESTE PROGRAMA MUESTRA EL USO DE FICHEROS DE TIPO TEXTO EN C*/


#include "cabecera.h"

main()
{
  int opcion; /*variable para opciones del menu */
  long auxdni; /*variable auxiliar para buscar por dni*/
  int salir; /*variable auxiliar usada en las operaciones de busqueda */
  int existe; /* variable auxiliar para si existe un fichero */
  int encontrado; /* variable que indica si el registro se ha encontrado */
  char auxNombre[15]; /* variable auxiliar para buscar por nombre */
  struct DatosPersonales persona1;
  FILE *pFichero;
  char fichero[15]; /* variable para el nombre del fichero */
  int nRegistro;
  
  /* Introduccion del nombre del fichero para trabajar */
  printf(" Nombre del fichero: ");
  scanf("%s",fichero);
  
  /* Menu de opciones del programa  */
  do
   {
    do
     {
      opcion = menu();
     } while (opcion < 0 || opcion > 8); /* obliga a que la opcion sea correcta */
     switch (opcion)
      {
        case 1: /* Anadir registros al fichero o crearlo si no existe*/
         {
          persona1 = introducirDatosPersonales();
          /* si el fichero no existe se anade el registro */
	  existe = existeFichero(fichero); /* comprueba si existe el fichero */
	  if (existe == 0) /* el fichero no existe*/
           {
	    /* se anade el regitro ya que seria el primero */
	    anadirRegistro(fichero, persona1);
	    printf(" Registro anadido. Pulse intro para seguir \n");
	   }
	  else /* el fichero existe */
	   {
	    /* Comprueba si esa persona ha sido introducida antes */
	    /* para no duplicar sus datos */
	    encontrado = buscarporDni(fichero, persona1.dni, &persona1);
	    if (encontrado == 1) /* ya existe el registro y no se anade */
	     {
	      printf(" Registro ya existente. Pulse intro para seguir \n");
	     }
	    else /* no existe el registro y se puede anadir */
	     {
	      anadirRegistro(fichero, persona1);
	      printf(" Registro anadido. Pulse intro para seguir \n");
	     }
	   }
	  getchar();
	  getchar();
	  break;
	 }

	case 2: /* Visualizar el contenido del fichero completo */
	 {
	  /* comprueba si existe el fichero */
          existe = existeFichero(fichero); 
	  if (existe == 1) /* el fichero existe */
	   {
	    
		 verFichero(fichero); /* muestra los registros del fichero */
	    printf(" Datos leidos. Pulse Intro para continuar \n");
	   }
	  else /* el fichero no existe */
	   {
	    printf(" El fichero no existe. Pulse intro para seguir \n");
	   }
	  getchar();
	  getchar();
	  break;
	 }
	 
	case 3: /* comprobar si existe un registro con dni dado */
	 {
	  existe = existeFichero(fichero); 
	  if (existe == 1) /* el fichero existe */
	   {
	    printf(" Introduzca dni a buscar: ");
	    scanf("%ld", &auxdni);
            encontrado = buscarporDni(fichero, auxdni, &persona1);
	    if (encontrado) /* se ha encontrado el registro */
	     {  
	      /* se escriben los datos de la persona */
	      escribirDatosPersonales(persona1); 
	      printf(" Registro Encontrado. Pulse Intro para continuar  \n");
	     }
	    else /* no se ha encontrado el registro */
	     {
	      printf("Registro no encontrado. Pulse Intro para continuar  \n");
	     }
	   }
	  else
	   {
	    printf(" El fichero no existe. Pulse intro para seguir \n");
	   }
	  getchar();
	  getchar();
	  break;	  
	 }

	case 4: /* ver todos los registros con un nombre dado */
	 {
	  existe = existeFichero(fichero); 
	  if (existe == 1) /* el fichero existe */
	   {
            getchar();
	    printf(" Introduzca nombre a buscar: ");
	    scanf("%s",auxNombre);
            encontrado = buscarporNombre(fichero, auxNombre);
	    if (encontrado == 0) /* No se ha encontrado ninguno */
	     printf(" No se ha encontrado ning�n registro. Pulse intro \n");
	    else
	     printf("Pulse intro para seguir \n");
	   }
	  else
	   {
	    printf(" El fichero no existe. Pulse intro para seguir \n");
	   }
	  getchar();
	  getchar();
	  break;	  
	 }
	 
	case 5: /* borrar un registro dado su dni*/
	 {
	  existe = existeFichero(fichero); 
	  if (existe == 1) /* el fichero existe */
	   {
            getchar();
	    printf(" Introduzca dni del registro a borrar: ");
	    scanf("%ld", &auxdni);
            encontrado = buscarporDni(fichero, auxdni, &persona1);
	    if (encontrado == 1) 
	    /* el registro existe y se puede borrar */
	     {
	      borrarporDni(fichero, auxdni);
	      printf("  Registro borrado. Pulse intro \n");
	     }
	    else /* no existe el registro */
	     printf(" No existe el registro. Pulse intro para seguir \n");
	   }
	  else /* el fichero no existe */
	   printf("  El fichero no existe. Pulse intro para seguir \n");
          getchar();
	  getchar();
	  break;	  
	 }
	case 6: //Contar numero de registros del fichero
	  printf("\nEl numero de registros del fichero es: %d\n", contarRegistros(fichero));
	  break;
	case 7: //Contar numero de bytes del fichero
	  printf("\nEl numero de bytes del fichero es: %d\n", contarBytes(fichero));   	 
	  break;
	case 8: //Ver registro i-esimo
	  printf("\nDime el numero de regristro ( i > 0 ) :");
	  scanf("%d", &nRegistro);
	  persona1=verRegistro_i(fichero, nRegistro);
	  printf("\nEl registro <%d> es: \n", nRegistro);
	  escribirDatosPersonales(persona1);  
	  break;  	 	 	  
      }  
   } while (opcion != 0);
}

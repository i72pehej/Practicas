//versi�n del programa cat
#include <stdio.h>
//----------------------------------------------------------
//Funcion: existeFichero
//Tarea: Comprueba la existencia de un fichero
//Recibe: char* nombre->El nombre del fichero
//Devuelve: int: 0 si el fichero no existe
//               1 si el fichero existe   
//----------------------------------------------------------
int existeFichero(char* nombre)
{
  FILE* f; //flujo asociado al fichero
  int existe=1;
  
  
  if((f=fopen(nombre, "r"))==NULL)
  { 
    existe=0;   
  }
  else
  {
    fclose(f); //CERRAMOS EL FICHERO!!	
  }
  return(existe); 	
}

//----------------------------------------------------------
//Funcion: fileCopy
//Tarea: Copia el contenido de un flujo en otro
//Recibe: nombreOrigen ->Nombre del fichero origen
//        nombreDestion->Nombre del fichero destino
//Devuelve: void
//----------------------------------------------------------
void fileCopy(char* nombreOrigen, char* nombreDestino)
{
  FILE* fOrigen, * fDestino;
  int c;
  
  fOrigen=fopen(nombreOrigen, "r");    
  fDestino=fopen(nombreDestino, "w");   
   
  while((c=getc(fOrigen))!=EOF)
  {
    putc(c, fDestino);
  }
  
  fclose(fOrigen);
  fclose(fDestino);	
}
//-----------------------------------------------------------
//           PROGRAMA PRINCIPAL
//-----------------------------------------------------------
int main()
{

  char nombreOrigen[]="fichtexto.txt";
  char nombreDestino[]="copiaFichero.txt";
  
  if(existeFichero(nombreOrigen))
  {
    fileCopy(nombreOrigen, nombreDestino);	
  }
  else
  {
    printf("\nEl fichero <%s> no existe", nombreOrigen);
    return(1);
  }
  
  return(0);
}


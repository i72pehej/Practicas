//Ejemplo de utilizacion de fscanf
#include "stdio.h"
#include "stdlib.h"

int main()
{

  FILE *pFichero;
  char fichero[15]; /* variable para el nombre del fichero */ 
  int entero;
  int n;

  /* Introduccion del nombre del fichero para trabajar */
  printf(" Nombre del fichero: ");  
  scanf("%s",fichero);  
 
  if((pFichero = fopen(fichero, "r"))==NULL)
  {
    /* abre fichero paa lectura */ 
    printf("Error al abrir fichero\n");
    exit(-1);
  }	 
  
  //Lectura anticipada
  fscanf(pFichero, "%d", &entero);
  while (!feof(pFichero))
  {
     printf("Entero leido: %d\n", entero);     
     n=fscanf(pFichero, "%d", &entero);
  }
  
  //Si el fichero no termina en '\n' hay que imprimir el �ltimo entero
  //porque justo tras la lectura se activa la marca de fin de fichero
  if(n==1)
     printf("Entero leido: %d\n", entero);     
  
  
  
  fclose(pFichero);
}


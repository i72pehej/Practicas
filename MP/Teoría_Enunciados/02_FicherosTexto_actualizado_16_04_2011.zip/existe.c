#include <stdio.h>
#define MAX_LINE 20


int existeFichero(char* nombre)
{
  FILE* f; //flujo asociado al fichero
  int existe=1;
  
  
  if((f=fopen(nombre, "r"))==NULL)
  { 
    existe=0;   
  }
  else
  {
    fclose(f); //CERRAMOS EL FICHERO!!	
  }
  return(existe); 	
}

int leeSiNo()
{
  char aux[MAX_LINE];
  int i;
  
  gets(aux);
  for(i=0; ((i<MAX_LINE)&&((aux[i]==' ')||(aux[i]=='\t'))); i++);
  if(i==MAX_LINE)
    return 0;
  else
    return(toupper((int)aux[i]));
  
}

void main()
{
  char nombreFichero[]="fichero.txt", respuesta;
  FILE* f;
  int existe=1;
  
  if(existeFichero(nombreFichero))
  {
    printf("\nEl fichero <%s> ya existe", nombreFichero);
    existe=1;
    do
    {
      printf("\n\tQuiere borrarlo?");
      respuesta = leeSiNo();      
    }while((respuesta!='S')&&(respuesta!='N'));
  }
  else
  {
     printf("\nEl fichero no existe");
     existe=0;
  }
  
  if(!existe)
  {
     printf("\nCreando el fichero....<%s>", nombreFichero);
  }
  else
  {
    if(respuesta=='S') //Existe y quiere borrarlo
    {
      printf("\nBorrando el antiguo <%s> y sustituyendolo", nombreFichero);	
    }
    else
    {
      printf("\nSeleccione otro fichero para continuar");	
    }
    
  }
}
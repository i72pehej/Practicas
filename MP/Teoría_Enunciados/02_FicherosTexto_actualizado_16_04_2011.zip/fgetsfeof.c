//Ejemplo de utilizaci�n de la funcion fgets

#include <stdio.h>

void leeVersion1(char* nombreFichero);
void leeVersion2(char* nombreFichero);
void leeVersion3(char* nombreFichero);

int main()
{
  printf("\nLectura de fichero version 1: ");
  printf("\n-----------------------------\n");
  leeVersion3("personas.txt");
  
 /* printf("\nPulse una tecla para continuar");
  getchar();
    
  printf("\nLectura de fichero version 2: ");
  printf("\n-----------------------------\n");
  leeVersion2("personas.txt");
*/
  return(0);
}


void leeVersion1(char* nombreFichero)
{
   FILE* fich;
   char cadena[30];
   
   fich=fopen(nombreFichero, "r");
   while(fgets(cadena, 30, fich)!=NULL)
   {     
     if(cadena[strlen(cadena)-1]=='\n')
       cadena[strlen(cadena)-1]='\0';
     printf("<%s>\n", cadena);   
   }
   fclose(fich);
	
}

void leeVersion2(char* nombreFichero)
{
   FILE* fich;
   char cadena[30];
   
   if((fich=fopen(nombreFichero, "r"))==NULL)
     printf("\nNo se ha podido abrir el fichero <%s>", nombreFichero);
   else
   {
      fgets(cadena, 30, fich);
      while(!feof(fich))
      {     
        if(cadena[strlen(cadena)-1]=='\n')
           cadena[strlen(cadena)-1]='\0';
        printf("<%s>\n", cadena);
        fgets(cadena, 30, fich); 
      }
      //si el fichero no termina en '\n' la ultima lectura
      //de fgets contiene la �ltima linea del fichero
      if(cadena[0]!='\n')
         printf("<%s>\n", cadena);
         
      fclose(fich);
    }  
	
}

void leeVersion3(char* nombreFichero)
{
   FILE* fich;
   char cadena[30];
   
   fich=fopen(nombreFichero, "r");
   while(fgets(cadena, 30, fich)!=NULL)
   {     
     if(cadena[strlen(cadena)-1]=='\n')
       cadena[strlen(cadena)-1]='\0';
     printf("\nNombre: <%s>\n", cadena);   
     
     fgets(cadena, 30, fich);
     if(cadena[strlen(cadena)-1]=='\n')
       cadena[strlen(cadena)-1]='\0';
     printf("\nApellidos: <%s>\n", cadena); 
     
     fgets(cadena, 30, fich);
     if(cadena[strlen(cadena)-1]=='\n')
       cadena[strlen(cadena)-1]='\0';
     printf("\nEdad: <%s>\n", cadena); 
     
   }
   fclose(fich);
	
}
/*-------------------------------------------------------------------*/
//EJEMPLO BASICO DE MATRICES CON GESTION DE MEMORIA DINAMICA
/*-------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define MAX_CASILLAS 10



/*******************************************************************/
/***********Funciones especificas de memoria dinamica***************/
/*******************************************************************/

/********************************************************************/
/*
   Nombre: reservaMatrizDinamicaPorFilas.
   Tipo: float**.
   Objetivo: Reserva memoria (por filas) para una matriz de flotantes.	     
   Parametros de entrada:
      - int nFil: N�mero de filas de la matriz.   
      - int nCol: N�mero de columnas de la matriz.
   Precondiciones: Ninguna.
   Valor devuelto: La matriz de dimension nFilxnCol.   
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
float** reservaMatrizDinamicaPorFilas(int nFil, int nCol);


/********************************************************************/
/*
   Nombre: reservaMatrizDinamicaPorFilasRef.
   Tipo: float**.
   Objetivo: Reserva memoria para una matriz de flotantes.	  
   Parametros de entrada:
      - int nFil: Numero de filas de la matriz. 
      - int nCol: Numero de columnas de la matriz.
      - float *** Matriz: Puntero a la direcci�n de memoria de la
                            primera fila de la matriz.
   Precondiciones: Ninguna.
   Valor devuelto: Ninguno.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/   
void reservaMatrizDinamicaPorFilasRef(float*** Matriz, int nFil, int nCol);
void reservaMatrizDinamicaPorFilasRef_punteros(float*** Matriz, int nFil, int nCol);

/********************************************************************/
/*
   Nombre: reservaMatrizDinamicaUnSoloBloque.
   Tipo: float**.
   Objetivo: Reserva memoria (en un solo bloque) para una matriz de flotantes.	     
   Parametros de entrada:
      - int nFil: N�mero de filas de la matriz.   
      - int nCol: N�mero de columnas de la matriz.
   Precondiciones: Ninguna.
   Valor devuelto: La matriz de dimension nFilxnCol.   
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
float** reservaMatrizDinamicaUnSoloBloque(int nFil, int nCol);

/********************************************************************/
/*
   Nombre: liberaMatrizDinamicaPorFilas
   Tipo: void.
   Objetivo: Libera la memoria reservada por filas para una matriz
             de flotantes.	     
   Parametros de entrada:
      - int nFil: Numero de filas de la matriz. 
      - float** Matriz Puntero a la direcci�n de memoria de la
                            primera fila de la matriz.
   Precondiciones: La matriz debe haber sido previamente creada (por filas)
                   con calloc, malloc, o realloc.
   Valor devuelto: Ninguno.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
void liberaMatrizDinamicaPorFilas(float** Matriz, int nFil);

/********************************************************************/
/*
   Nombre: liberaMatrizDinamicaUnSoloBloque
   Tipo: void.
   Objetivo: Libera la memoria reservada en un solo bloque para una matriz
             de flotantes.	     
   Parametros de entrada:
      - int nFil: Numero de filas de la matriz. 
      - float** Matriz Puntero a la direcci�n de memoria de la
                            primera fila de la matriz.
   Precondiciones: La matriz debe haber sido previamente creada
                   (en un solo bloque) con calloc, malloc, o realloc.
   Valor devuelto: Ninguno.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
void liberaMatrizDinamicaUnSoloBloque(float** Matriz);


/*******************************************************************/
/***********************Funciones auxiliares************************/
/*******************************************************************/


//Funciones de apoyo
void leeNFilNCol(int* nFil, int*nCol);
void rellenaMatrizAleatorios(float** Matriz, int nFil, int nCol);
void pintaMatriz(float** Matriz, int nFil, int nCol);

/*******************************************************************/
/******************************MAIN*********************************/
/*******************************************************************/

void main()
{
  float** Matriz; //Matriz bidimensional
  int nFil;
  int nCol; //Numero de filas y columnas de la matriz 
 
 
  leeNFilNCol(&nFil, &nCol);  
    
  //1.RESERVA DINAMICA DE MEMORIA POR FILAS   
  reservaMatrizDinamicaPorFilasRef(&Matriz, nFil, nCol);
  //if((Matriz = reservaMatrizDinamicaPorFilas(nFil, nCol))==NULL)
  //{
  //  printf("Error en reserva de memoria\n");
  //  exit (-1);
  //}
   
  rellenaMatrizAleatorios(Matriz, nFil, nCol);
  printf("\nMatriz dinamica reservada por filas:\n");
  printf("------------------------------------\n");
  pintaMatriz(Matriz, nFil, nCol);
  liberaMatrizDinamicaPorFilas(Matriz, nFil);
  
  //2.RESERVA DINAMICA DE MEMORIA EN UN SOLO BLOQUE
  if((Matriz = reservaMatrizDinamicaUnSoloBloque(nFil, nCol))==NULL)
  {
    printf("Error en reserva de memoria\n");
    exit (-1);  	
  }
  rellenaMatrizAleatorios(Matriz, nFil, nCol);
  printf("\nMatriz dinamica reservada en un solo bloque:\n");
  printf("------------------------------------\n");
  pintaMatriz(Matriz, nFil, nCol);  
  liberaMatrizDinamicaUnSoloBloque(Matriz);
}


/*******************************************************************/
/***********Funciones especificas de memoria dinamica***************/
/*******************************************************************/

float** reservaMatrizDinamicaPorFilas(int nFil, int nCol)
{
  float** Matriz;
  int i, j, error =0;
  
  if((Matriz=(float**)malloc(nFil*sizeof(float*)))==NULL)
  {
    printf("Error en reserva de memoria\n");
  }
  else
  {
    for(i=0; (i<nFil)&&(!error);i++)
    {
       if((Matriz[i]=(float*)malloc(nCol*sizeof(float)))==NULL)
       {
         printf("Error en reserva de memoria\n");
         error = 1;
         //Libera la memoria reservada antes de producirse el error
         for(j= i-1; j>=0; j--)
         {
           free(Matriz[j]);
         }
         free(Matriz);
         Matriz=NULL;
       }      
    }
  }
  return(Matriz);
}
/*-------------------------------------------------------------------*/
void reservaMatrizDinamicaPorFilasRef(float *** Matriz, int nFil, int nCol)
{
  int i, j, error =0;
  
  if((*Matriz=(float**)malloc(nFil*sizeof(float*)))==NULL)
  {
    printf("Error en reserva de memoria\n");
  }
  else
  {
    for(i=0; (i<nFil)&&(!error);i++)
    {
       if(((*Matriz)[i]=(float*)malloc(nCol*sizeof(float)))==NULL)
       {
         printf("Error en reserva de memoria\n");
         error = 1;
         //Libera la memoria reservada antes de producirse el error
         for(j= i-1; j>=0; j--)
         {
           free((*Matriz)[j]);
         }
         free(*Matriz);
         Matriz=NULL;
       }      
    }
  }  
}


void reservaMatrizDinamicaPorFilasRef_punteros(float *** Matriz, int nFil, int nCol)
{
  int i, j, error =0;
  
  if((*Matriz=(float**)malloc(nFil*sizeof(float*)))==NULL)
  {
    printf("Error en reserva de memoria\n");
  }
  else
  {
    for(i=0; (i<nFil)&&(!error);i++)
    {
       if(
       (*((*Matriz)+i)=(float*)malloc(nCol*sizeof(float)))
       ==NULL)
       {
         printf("Error en reserva de memoria\n");
         error = 1;
         //Libera la memoria reservada antes de producirse el error
         for(j= i-1; j>=0; j--)
         {
           free(*((*Matriz)+j));
         }
         free(*Matriz);
         Matriz=NULL;
       }      
    }
  }  
}

/*-------------------------------------------------------------------*/
float** reservaMatrizDinamicaUnSoloBloque(int nFil, int nCol)
{
   float** Matriz;
   int i;
   
   if((Matriz=(float**)malloc(nFil*sizeof(float*)))==NULL)
   {
      printf("Error en la reserva de memoria\n");
   }
   else
   {
     if((Matriz[0]=(float*)malloc(nFil*nCol*sizeof(float)))==NULL)
     {
       printf("Error en la reserva de memoria\n");
       free(Matriz);
     }
     else
     { 
     	for(i=1; i<nFil; i++)
     	{        
     	  Matriz[i]=Matriz[i-1]+nCol; 
        }        
     }     
   }
   return(Matriz);

}

/*-------------------------------------------------------------------*/
void liberaMatrizDinamicaPorFilas(float** Matriz, int nFil)
{
  int i;
  
  for(i=0; i<nFil; i++)
  {
    free(Matriz[i]);   
  }
  free(Matriz);
  
  //Si quisieramos poner Matriz a NULL, hay que pasarla por referencia
}

void liberaMatrizDinamicaUnSoloBloque(float** Matriz)
{
  free(Matriz[0]);
  free(Matriz);	
}
/*-------------------------------------------------------------------*/

/*******************************************************************/
/***********************Funciones auxiliares************************/
/*******************************************************************/

void leeNFilNCol(int* nFil, int* nCol)
{
  do
  {
    printf("\nIntroduzca el numero de filas de la matriz\n");
    scanf("%d", nFil);    
  }while((*nFil<0)||(*nFil>MAX_CASILLAS));	
  
  do
  {
    printf("\nIntroduzca el numero de columnas de la matriz\n");
    scanf("%d", nCol);    
  }while((*nCol<0)||(*nCol>MAX_CASILLAS));	        
  
}
/*-------------------------------------------------------------------*/
void rellenaMatrizAleatorios(float** Matriz, int nFil, int nCol)
{
  time_t t;
  int i, j;
  float aux;
  
  //inicializa la semilla de numeros aleatorios
  srand((unsigned)time(&t));
  
  for(i=0; i<nFil; i++)
  {
    for(j=0; j<nCol; j++)
    {
    	//numero aleatorio entre 1 y 100, por esto hacemos modulo 101
    	aux = rand()%101;
    	Matriz[i][j]= aux; 
    }
  }
}
/*-------------------------------------------------------------------*/
void pintaMatriz(float** Matriz, int nFil, int nCol)
{
  int i, j;
  
  for(i=0; i<nFil; i++)
  {
    for(j=0; j<nCol; j++)
    {
    	printf("\t\tMatriz[%d][%d]: %f\n", i, j, Matriz[i][j]);
    }
  }
}

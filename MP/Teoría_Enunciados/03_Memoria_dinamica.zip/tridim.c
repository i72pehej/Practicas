/*-------------------------------------------------------------------*/
//EJEMPLO BASICO DE MATRICES TRIDIMENSIONALES CON GESTION DE MEMORIA DINAMICA
/*-------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>

/********************************************************************/
/*
   Nombre: reservaMatrizTridimensional.
   Tipo: float***.
   Objetivo: Reserva memoria para una matriz de tres dimensiones de flotantes.	  
   Parametros de entrada:
      - int nFil: Numero de filas de la matriz. 
      - int nCol: Numero de columnas de la matriz.
      - int nAlt: Numero de alturas de la matriz.
   Precondiciones: Ninguna.
   Valor devuelto: La matriz tridimensional.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/   
float*** reservaMatrizTridimensional(int nFil, int nCol, int nAlt)
{
  float*** Matriz;
  int i, j;
  
  Matriz=(float***)malloc(nFil*sizeof(float**));
  for(i=0; i<nFil;i++)
  {
       Matriz[i]=(float**)malloc(nCol*sizeof(float*));
       for(j=0; j<nCol; j++)
       {
         Matriz[i][j]=(float*)malloc(nAlt*sizeof(float));
       }          
  }

  return(Matriz);
}

/********************************************************************/
/*
   Nombre: liberaMatrizTridimensional
   Tipo: void.
   Objetivo: Libera la memoria reservada (por filas) filas para una matriz
             tridimensional de flotantes.	     
   Parametros de entrada:
      - int nFil: Numero de filas de la matriz. 
      - int nCol: Numero de columnas de la matriz.
      - float*** Matriz Puntero a la direcci�n de memoria de la
                            primera fila de la matriz.
   Precondiciones: La matriz debe haber sido previamente creada (por filas)
                   con calloc, malloc, o realloc.
   Valor devuelto: Ninguno.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
void liberaMatrizTridimensional(float*** Matriz, int nFil, int nCol)
{
  int i, j;
  
  for(i=0; i<nFil; i++)
  {
    for(j=0; j<nCol; j++)
    {
      free(Matriz[i][j]);   
    }
    free(Matriz[i]);  
  }
  free(Matriz);
}

/*******************************************************************/
/******************************MAIN*********************************/
/*******************************************************************/

int main()
{
  int nFil, nCol, nAlt, i, j, k;
  float *** Matriz;
  
  printf("\nIntroducir numero de filas: ");
  scanf("%d", &nFil);
  printf("\nIntroducir numero de columnas: ");
  scanf("%d", &nCol);
  printf("\nIntroducir numero de Alturas: ");
  scanf("%d", &nAlt);
  
  Matriz = reservaMatrizTridimensional(nFil, nCol, nAlt);  
  for(i=0; i<nFil; i++)
  {
    for(j=0; j<nCol; j++)
    {
      for(k=0; k<nAlt; k++)
      {
        Matriz[i][j][k]= j;	
        printf("\nMatriz[%d][%d][%d]: %f", i, j, k, Matriz[i][j][k]);
      }	
    }	
  }
  liberaMatrizTridimensional(Matriz, nFil, nCol); 	
}

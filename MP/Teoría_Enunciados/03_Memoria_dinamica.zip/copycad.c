/*-------------------------------------------------------------------*/
//Demostraci�n del uso de las funciones de memoria dinamica
//Lee una cadena e intenta copiarla en otra que inicialmente es
//demasiado peque�a. Se solicita m�s memoria hasta que se dispone del
//espacio suficiente para hacer la copia
/*-------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LENGTH 100 //maxima longitud de la cadena a copiar
#define FACTOR 5       //incremento de reserva de memoria


/*******************************************************************/
/******************************MAIN*********************************/
/*******************************************************************/

int main()
{
  char cadenaOrigen[MAX_LENGTH]; //cadena a copiar (original)
  char* cadenaDestino;                //puntero a la cadena resultado
  
  int tam = FACTOR;       //Tama�o de la memoria reservada para albergar la copia
  int seguir = 1;
  
  //primera peticion de memoria para la copia
  if((cadenaDestino=(char*)malloc(tam*sizeof(char)))==NULL)
  {
    printf("Error en reserva de memoria\n");
    exit(-1);	
  }
  
  //peticion de la cadena a copiar
  printf("\nIntroducir una cadena: ");
  gets(cadenaOrigen);
  printf("\tEsta cadena contiene ahora: <%s>\n", cadenaOrigen);
  printf("\tSu longitud es: %d\n", strlen(cadenaOrigen));
  
  
  //repite mientras no se pueda copiar
  do
  {
    printf("\tIntentando copiarla en otra de longitud %d\n", tam);
    
    if(strlen(cadenaOrigen)>=tam) //No cabe, pedir mas memoria
    {
    	printf("\t\tLa cadena no cabe\n");
    	printf("\t\t\tReservando hasta %d elementos\n", tam+FACTOR);
    	
    	//Solicitar FACTOR casillas mas
    	if((cadenaDestino = (char*)realloc(cadenaDestino,(tam+FACTOR)*sizeof(char)))==NULL)
    	{
    	  printf("Error en reserva de memoria");
    	  exit(-1);
        }
        tam = tam+FACTOR;
    }
    else  //Cabe, copiarla y terminar
    {
    	printf("\t\tLa cadena ya cabe\n");
    	printf("\t\t\tCopiandola (con %d casillas)\n", tam);
    	
    	//Copia con garantia de que hay sitio
    	strcpy(cadenaDestino, cadenaOrigen);
    	printf("\tLa cadena final contiene: <%s>", cadenaDestino);
    	printf("\tSu longitud es: %d\n", strlen(cadenaDestino));
    	
    	seguir=0; //para salir del bucle do....while    	
    }	
    
  }while(seguir);
 
  //Liberamos memoria
  free(cadenaDestino);   
  return(0);
}



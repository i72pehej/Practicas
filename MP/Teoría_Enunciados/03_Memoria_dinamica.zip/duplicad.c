/*-------------------------------------------------------------------*/
//Ejemplo de copia de cadenas estaticas a dinamicas
/*-------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/********************************************************************/
/*
   Nombre: duplica.
   Tipo: char*.
   Objetivo: Copia una cadena en otra, que contiene el minimo espacio
             necesario.	     
   Parametros de entrada:
      - char* origen: Cadena fuente. 
   Precondiciones: Ninguna.
   Valor devuelto:
      - char*: Cadena destino, NULL si hay alg�n problema.
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
char* duplica(char* origen)
{
  char* ptr;
  
  if((ptr=(char*)malloc((strlen(origen)+1)*sizeof(char)))==NULL) //+1 para el \0
  {
     printf("Error: no pudo asignarse memoria\n");
     return(NULL);
  }
  else
  {
    strcpy(ptr, origen);
    return(ptr);
  }
}

/*******************************************************************/
/******************************MAIN*********************************/
/*******************************************************************/

int main()
{
  char origen[10];
  char* destino; //No se reserva memoria para la cadena copia, solo un puntero
  
  printf("Introducir cadena origen:\n");
  gets(origen);
  
  //Antes de llamar a duplica:
  //destino
  //-----
  //| ? |
  //-----  	
  //
  //origen
  //------------------------------------------
  //|'h'|'o'|'l'|'a'|'\0'| ? | ? | ? | ? | ? |
  //------------------------------------------
  //  0   1   2   3    4   5   6   7   8   9
  
  destino = duplica(origen);
  printf("Origen: <%s>  Longitud: %d\n", origen, strlen(origen));
  printf("Destino: <%s>  Longitud: %d\n", destino, strlen(destino));
  
  free(destino);
  return(0);  
}



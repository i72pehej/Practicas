/*-------------------------------------------------------------------*/
//EJEMPLO BASICO DE VECTORES CON GESTION DE MEMORIA DINAMICA
/*-------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>

/********************************************************************/
/*
   Nombre: reservaVector.
   Tipo: int*.
   Objetivo: Reserva memoria para un vector de enteros.	     
   Parametros de entrada:
      - int nElementos: N�mero de elementos del vector.   
   Precondiciones: Ninguna.
   Valor devuelto: La direcci�n de memoria del primer elemento del vector.   
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
int* reservaVector(int nElementos)
{
  int* p;
  if((p=(int*)calloc(nElementos,sizeof(int)))==NULL)
  {
    printf("\nError en reserva de memoria\n");	
    exit(-1);
  }  
  return(p);  	
}

/********************************************************************/
/*
   Nombre: reservaVectorReferencia.
   Tipo: void.
   Objetivo: Reserva memoria para un vector de enteros.	     
   Parametros de entrada:
      - int nElementos: N�mero de elementos del vector.   
      - int** Vector: puntero a la direcci�n de memoria del primer elemento
                      del vector
   Precondiciones: Ninguna.
   Valor devuelto: Ninguno.   
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
void reservaVectorReferencia(int** Vector, int nElementos)
{
  if((*Vector=(int*)calloc(nElementos,sizeof(int)))==NULL)
  {
    printf("\nError en reserva de memoria\n");	
    exit(-1);
  }      	
}

/********************************************************************/
/*
   Nombre: llenaVector.
   Tipo: void.
   Objetivo: Inicializa un vector de enteros.	     
   Parametros de entrada:
      - int nElementos: N�mero de elementos del vector. 
      - int* Vector: El vector de enteros.  
   Precondiciones: Ninguna.
   Valor devuelto: Ninguno.   
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
void llenaVector(int nElementos, int* Vector)
{
  int i;	
  
  for(i=0; i<nElementos; i++)
  {
    Vector[i] = i;
  }
}

/********************************************************************/
/*
   Nombre: PintaVector.
   Tipo: void.
   Objetivo: Muestra en pantalla un vector de enteros.	     
   Parametros de entrada:
      - int nElementos: N�mero de elementos del vector. 
      - int* Vector: El vector de enteros.  
   Precondiciones: Ninguna.
   Valor devuelto: Ninguno.   
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
void pintaVector(int nElementos, int* Vector)
{
  int i;
  
  for(i=0; i<nElementos; i++)
  {
    printf("\tVector[%d]: %d\n", i, Vector[i]);    
  }   	
}

/*******************************************************************/
/******************************MAIN*********************************/
/*******************************************************************/

void main()
{
  int* p; //Puntero a enteros
  int noVale[5];
  int i, nElementos=5;
  
  //1.RESERVA NO VALIDA
  //La siguiente linea da error de compilacion
  //no podemos asignar memoria dinamica a un
  //vector declarado estaticamente
  //noVale = (int*) malloc (nElementos*sizeof(int));
  
  //2.RESERVA DE MEMORIA CON MALLOC
  //Comprobar si se ha podido hacer la reserva
  if((p=(int*)malloc(nElementos*sizeof(int)))==NULL)
  {
    printf("\nError en reserva de memoria\n");	
    exit(-1);
  }
  //inicializamos el vector
  for(i=0; i<nElementos; i++)
  {
    p[i] = (nElementos-1)+i;
  }
  //escribimos el vector
  printf("Vector reservado con MALLOC:\n");  
  pintaVector(nElementos, p);  
  
  //MUY IMPORTANTE: no olvidar liberar memoria
  //cuando ya no vaya a ser utilizada
  free(p);
  
  //2.RESERVA DE MEMORIA CON CALLOC
  //  Otras formas equivalentes
  //reservaVectorReferencia(&p, nElementos);
  if((p=reservaVector(nElementos))==NULL)  
  //if((p=(int*)calloc(nElementos,sizeof(int)))==NULL)  
  {
    printf("\nError en reserva de memoria\n");	
    exit(-1);
  } 
  llenaVector(nElementos, p);  
  printf("Vector reservado con CALLOC:\n");
  pintaVector(nElementos, p);  
  
  //3.USO DE REALLOC
  //doblar el tama�o del vector anterior
  if((p=(int*)realloc(p,nElementos*2*sizeof(int)))==NULL)
  {
    printf("\nError en reserva de memoria\n");	
    exit(-1);
  }
  //inicializamos los nuevos valores del vector
  llenaVector(nElementos*2, p);
  printf("Vector tras hacer REALLOC:\n");
  pintaVector(nElementos*2, p);      
  
  
  //MUY IMPORTANTE: no olvidar liberar memoria
  //cuando ya no vaya a ser utilizada
  free(p); 
  
}


/*-------------------------------------------------------------------*/
//Ejemplo utilizacion de vectores y matrices DINAMICOS de estructuras
/*-------------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>

struct dato
{
  int n;	
};

/********************************************************************/
/*
   Nombre: reservaVectorStr.
   Tipo: struct dato*.
   Objetivo: Reserva un vector de struct dato.	     
   Parametros de entrada:
      - int nEle: Numero de elementos del vector. 
   Precondiciones: Ninguna.
   Valor devuelto:
      - struct dato*: El vector de nEle elementos.
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
struct dato* reservaVectorStr(int nEle)
{
  struct dato* ptr;
  
  if((ptr=(struct dato*)malloc(nEle*sizeof(struct dato)))==NULL)
  {
    printf("\nError en la reserva de memoria");
    exit(-1);
  }
  return(ptr); 
}

/********************************************************************/
/*
   Nombre: reservaVectorStrReferencia.
   Tipo: struct dato*.
   Objetivo: Reserva un vector de struct dato.	     
   Parametros de entrada:
      - int nEle: Numero de elementos del vector. 
      - struct dato**: puntero a la direcci�n de memoria del primer elemento
                      del vector
   Precondiciones: Ninguna.
   Valor devuelto: Ninguno.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
void reservaVectorStrReferencia(struct dato** ptr, int nEle)
{
  if((*ptr=(struct dato*)malloc(nEle*sizeof(struct dato)))==NULL)
  {
    printf("\nError en la reserva de memoria");
    exit(-1);
  }  
}

/********************************************************************/
/*
   Nombre: liberaVectorStr.
   Tipo: void.
   Objetivo: Libera la memoria reservada para un vector de struct dato.	     
   Parametros de entrada: 
      - struct dato**: puntero a la direcci�n de memoria del primer elemento
                      del vector
   Precondiciones: El vector debe haber sido creado previamente con
                   calloc, malloc, o realloc.
   Valor devuelto: Ninguno.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
void liberaVectorStr(struct dato* ptr)
{
  free(ptr);	
}

/********************************************************************/
/*
   Nombre: rellenaVectorStr.
   Tipo: void.
   Objetivo: Inicializa un vector de struct dato.	     
   Parametros de entrada:
      - int nEle: Numero de elementos del vector. 
      - struct dato* ptr: El vector
   Precondiciones: Ninguna.
   Valor devuelto: Ninguno.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/	
void rellenaVectorStr(struct dato* ptr, int nEle)
{
  int i;
  
  for(i=0; i<nEle; i++)
  {
    ptr[i].n = i;
  }	
}

/********************************************************************/
/*
   Nombre: muestraVectorStr.
   Tipo: void.
   Objetivo: Escribe en pantall un vector de struct dato.	     
   Parametros de entrada:
      - int nEle: Numero de elementos del vector. 
      - struct dato* ptr: El vector
   Precondiciones: Ninguna.
   Valor devuelto: Ninguno.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/	
void muestraVectorStr(struct dato* ptr, int nEle)
{
  int i;  
  
  for(i=0; i<nEle; i++)
  {
    printf("\nVectorDeEstructuras[%d].n:%d", i, ptr[i].n);
  }		
}

/********************************************************************/
/*
   Nombre: reservaMatrizStr.
   Tipo: struct dato**.
   Objetivo: Reserva una matriz de struct dato.	     
   Parametros de entrada:
      - int nFil: Numero de filas de la matriz. 
      - int nCol: Numero de columnas de la matriz.
   Precondiciones: Ninguna.
   Valor devuelto:
      - struct dato**: La matriz de dimension nFilxnCol.
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
struct dato** reservaMatrizStr(int nFil, int nCol)
{
  struct dato** ptr;
  int i;
  
  if((ptr=(struct dato**)malloc(nFil*sizeof(struct dato*)))==NULL)
  {
    printf("\nError en la reserva de memoria (1)");
    exit(-1);
  }
  else
  {
    for(i=0; i<nFil; i++)
    {
       if((ptr[i]=(struct dato*)malloc(nCol*sizeof(struct dato)))==NULL)
       {
         printf("\nError en la reserva de memoria (2)");
         exit(-1);
       }    	
    }	
  }
  return(ptr); 
}

/********************************************************************/
/*
   Nombre: reservaMatrizStrReferencia.
   Tipo: void.
   Objetivo: Reserva una matriz de struct dato.	     
   Parametros de entrada:
      - int nFil: Numero de filas de la matriz. 
      - int nCol: Numero de columnas de la matriz.
      - struct dato*** ptr: Puntero a la direcci�n de memoria de la
                            primera fila de la matriz.
   Precondiciones: Ninguna.
   Valor devuelto: Ninguno.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
void reservaMatrizStrReferencia(struct dato*** ptr, int nFil, int nCol)
{
  int i;
  if((*ptr = (struct dato**)malloc(nFil*sizeof(struct dato*)))==NULL)
  {
    printf("\nError en la reserva de memoria (1)");
    exit(-1);  	
  }
  
  for(i=0; i<nFil; i++)
  {
    if(((*ptr)[i] = (struct dato*)malloc(nCol*sizeof(struct dato)))==NULL)
    {
      printf("\nError en la reserva de memoria (2)");
      exit(-1);  	    	
    }
  }
}

/********************************************************************/
/*
   Nombre: LiberaMatrizStr.
   Tipo: void.
   Objetivo: Libera la memoria reservada para una matriz de struct dato.	     
   Parametros de entrada:
      - int nFil: Numero de filas de la matriz.       
      - struct dato*** ptr: Puntero a la direcci�n de memoria de la
                            primera fila de la matriz.
   Precondiciones: La matriz debe haber sido previamente creada con
                   calloc, malloc, o realloc.
   Valor devuelto: Ninguno.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/
void liberaMatrizStr(struct dato*** ptr, int nFil)
{
  int i;
  
  for(i=0; i<nFil; i++)
  {
    free((*ptr)[i]);	
  }
  free(*ptr);  
}
/********************************************************************/
/*
   Nombre: rellenaMatrizStr.
   Tipo: void.
   Objetivo: Inicializa una matriz de struct dato.	     
   Parametros de entrada:
      - int nFil: Numero de filas de la matriz.
      - int nCol: Numero de columnas de la matriz. 
      - struct dato** ptr: La matriz.
   Precondiciones: Ninguna.
   Valor devuelto: Ninguno.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/		
void rellenaMatrizStr(struct dato** ptr, int nFil, int nCol)
{
  int i, j;
  
  for(i=0; i<nFil; i++)
  {
     for(j=0; j<nCol; j++)
     {
       ptr[i][j].n = i;
     }  
  }	
}

/********************************************************************/
/*
   Nombre: muestraMatrizStr.
   Tipo: void.
   Objetivo: Escribe en pantalla una matriz de struct dato.	     
   Parametros de entrada:
      - int nFil: Numero de filas de la matriz.
      - int nCol: Numero de columnas de la matriz. 
      - struct dato** ptr: La matriz.
   Precondiciones: Ninguna.
   Valor devuelto: Ninguno.      
   Fecha de creaci�n: 25-04-05.
   Autor:   
*/
/*******************************************************************/	
void muestraMatrizStr(struct dato** ptr, int nFil, int nCol)
{
  int i, j;
  
  for(i=0; i<nFil; i++)
  {
     for(j=0; j<nCol; j++)
     {
       printf("\nMatrizDeEstructuras[%d][%d].n:%d", i,j, ptr[i][j].n);
     }  
  }  	
}

/*******************************************************************/
/******************************MAIN*********************************/
/*******************************************************************/
void main()
{
  int nEle=10, i, nFil=3, nCol=2;  
  struct dato* D;
  struct dato** M;
  
  
  //reservaVectorStrReferencia(&D, nEle);
  D= reservaVectorStr(nEle);
  rellenaVectorStr(D, nEle);
  muestraVectorStr(D, nEle);  
  liberaVectorStr(D);
    
  //reservaMatrizStrReferencia(&M, nEle, nEle+1);
  M= reservaMatrizStr(nFil, nCol);
  rellenaMatrizStr(M, nFil, nCol);
  muestraMatrizStr(M, nFil, nCol);  
  
  liberaMatrizStr(&M, nFil);
  //EQUIVALENTE:
  //for(i=0; i<nFil; i++)
  //{
  //  free(M[i]);    	
  //}
  //free(M);
}




 
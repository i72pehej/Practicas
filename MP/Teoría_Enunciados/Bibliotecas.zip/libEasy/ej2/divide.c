#include "opers.h"

float divide (int a, int b)
{
  return((a*1.0)/b);
}


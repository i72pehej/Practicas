#include "opers.h"

int multiplica(int a, int b)
{
  return(a*b);	
}


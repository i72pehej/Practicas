#include "opers.h"

int resta(int a, int b)
{
  return(a-b);	
}
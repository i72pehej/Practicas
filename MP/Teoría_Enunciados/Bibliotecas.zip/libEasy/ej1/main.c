/*------------------------------------------------------------------*/
/* EJEMPLO BASICO DE GESTION DE BIBLIOTECAS CON EL PROGRAMA ar      */
/*------------------------------------------------------------------*/
#include <stdio.h>
#include "opers.h"

void main()
{
    printf("%d\n", suma(2,5));	
}

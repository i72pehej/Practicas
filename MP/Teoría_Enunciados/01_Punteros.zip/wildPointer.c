#include <stdio.h>
#include <string.h>
int main() 
{
  char *p;
  strcpy (p, "wxsjkwe");
  printf("<%s>", p);
  return 0;
}

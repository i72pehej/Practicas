#include <stdio.h>

void main()
{
  float* pf;
  char c;
  pf=&c; //No es v�lido
}

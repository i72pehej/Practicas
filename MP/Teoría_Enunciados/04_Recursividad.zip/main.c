/*------------------------------------------------------------------*/
/* EJEMPLOS BASICOS DE RECURSIVIDAD  EN C                           */
/*------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include "recur.h"


/*******************************************************************/
/********************** PROGRAMA PRINCIPAL *************************/
/*******************************************************************/
void main()
{
  int opcion, i;
  int numero, a, b;
  int salir = 0;
  int V[maxElem]={5,7,3,1,11,13,17};
  int Valeatorio[maxElem]; 


 
  printf("\n------------------------------------------\n");  
  
  do
  {
    printf("\nIntroduzca la opcion:\n");
    printf("\t1.Factorial de un numero\n");
    printf("\t2.Traza de la ejecucion recursiva del factorial\n");    
    printf("\t3.Factorial mal. Ojo con el paso de parametros\n");
    printf("\t4.Potencia de dos numeros a^b\n");    
    printf("\t5.Suma recursiva a+b\n");
    printf("\t6.Producto recursivo a*b\n");
    printf("\t7.Suma recursiva de los elementos de un vector\n");
    printf("\t8.Suma recursiva de los elementos de un vector generado ALEATORIAMENTE\n");    
    printf("\t9.Determinar el elemento mayor de un vector\n");
    printf("\t10.Escribir un vector ALETORIO de forma recursiva\n");    
    printf("\t11.Escribir e INVERTIR un vector de forma recursiva un vector ALEATORIO\n");        
    printf("\t12.Sucesion de fibonacci recursiva\n");
    printf("\t13.Sucesion de fibonacci iterativa\n");
    printf("\t14.Busqueda lineal de un elemento en un vector\n");            
    printf("\t15.Buscar los dos elementos mayores de un vector\n");
    printf("\t16.Buscar los dos elementos mayores de un vector ALEATORIO\n");    
    printf("\t100.Salir\n");    
    scanf("%d", &opcion);
    printf("\n");
 
    switch(opcion)
    {
      case 1: /*Factorial de un numero*/
             printf("\tFactorial de un numero\n");
             printf("\tIntroduzca numero: ");
             scanf("%d", &numero);
             printf("\n\tfactorial(%d)=%d\n", numero, factorial(numero));
             break; 
      case 2: /*Factorial trazado*/       
             printf("\tFactorial de un numero(traza de la ejecucion)\n");
             printf("\tIntroduzca numero: ");
             scanf("%d", &numero);
             printf("\n\tfactorial(%d)=%d\n", numero, factorialVerbose(numero));
             break;
      case 3:/*Factorial mal*/       
             printf("\tFactorial con paso de parametros incorrecto\n");
             printf("\tIntroduzca numero: ");
             scanf("%d", &numero);
             printf("\n\tfactorial(%d)=%d\n", numero, factorialMalVerbose(&numero));
             break;
      case 4:/*Potencia a^b*/
             printf("\tPotencia de dos numeros a^b\n");
             printf("\tIntroduzca base: ");
             scanf("%d", &a);
             printf("\tIntroduzca exponente: ");
             scanf("%d", &b);            
             printf("\n\tpotencia(%d, %d)=%d\n", a, b, potencia(a, b));
             break;                  
      case 5:/*suma recursiva a+b*/
             printf("\tSuma recursiva de dos numeros a+b\n");
             printf("\tIntroduzca primer sumando: ");
             scanf("%d", &a);
             printf("\tIntroduzca segundo sumando: ");
             scanf("%d", &b);            
             printf("\n\tsuma(%d, %d)=%d\n", a, b, suma(a, b));
             break;                  
      case 6:/*producto recursivo a*b*/
             printf("\tProducto recursivo de dos numeros a*b\n");
             printf("\tIntroduzca primer multiplicando: ");
             scanf("%d", &a);
             printf("\tIntroduzca segundo multiplicando: ");
             scanf("%d", &b);            
             printf("\n\tproducto(%d, %d)=%d\n", a, b, producto(a, b));
             break;                               
      case 7:/*Suma recursiva de los elementos de un vector*/
             printf("\tSuma recursiva de los elementos de un vector\n");
             for(i=0; i<=6; i++)
             {
             	printf("\tV[%d]=%d\n", i, V[i]);
             }	
             printf("\n\tsumaElementosVector =%d\n", sumaElementosVector(V, 6));
             break;
      case 8:/*Suma recursiva de los elementos de un vector generado ALEATORIAMENTE*/
             printf("\tSuma recursiva de los elementos de un vector generado aleatoriamente\n");
             generaAleatorios(Valeatorio, (maxElem/2)-1);
             for(i=0; i<(maxElem/2); i++)
             {
               printf("\tVectorAleatorio[%d]=%d\n", i, Valeatorio[i]);
             }             
             printf("\n\tsumaElementosVector =%d\n", sumaElementosVector(Valeatorio, (maxElem/2)-1));
             break;                             
             
      case 9:/*Encontrar el elemento mayor de un vector generado ALEATORIAMENTE*/
             printf("\tEncontrar el mayor de los elementos de un vector generado aleatoriamente\n");
             generaAleatorios(Valeatorio, (maxElem/2)-1);
             for(i=0; i<(maxElem/2); i++)
             {
             	printf("\tVectorAleatorio[%d]=%d\n", i, Valeatorio[i]);
             }             
             printf("\nMayor=%d\n", mayor(Valeatorio, (maxElem/2)-1));
             break;       
                      
      case 10:/*Recorrer y escribir un vector generado ALEATORIAMENTE*/
             printf("\tRecorre y escribe un vector generado aleatoriamente\n");
             generaAleatorios(Valeatorio, (maxElem/2)-1);
             for(i=0; i<(maxElem/2); i++)
             {
             	printf("\tVectorAleatorio[%d]=%d\n", i, Valeatorio[i]);
             }
             printf("\nVector escrito recursivamente: \n");             
             escribirVector(Valeatorio, (maxElem/2)-1);
             break;
             
      case 11:/*Invertir y escribir un vector generado ALEATORIAMENTE*/
             printf("\tRecorre e invierte un vector generado aleatoriamente\n");
             generaAleatorios(Valeatorio, (maxElem/2)-1);
             for(i=0; i<(maxElem/2); i++)
             {
             	printf("\tVectorAleatorio[%d]=%d\n", i, Valeatorio[i]);
             }
             printf("\nVector INVERTIDO escrito recursivamente: \n");             
             escribirVectorInvertido(Valeatorio, (maxElem/2)-1);
             break;                                  
             
      case 12: /*Sucesi�n de fibonacci recursiva*/       
             printf("\tSucesion de fibonacci recursiva para un n dado\n");
             printf("\tIntroduzca numero: ");
             scanf("%d", &numero);
             printf("\n\tfibonacciRecursivo(%d)=%d\n", numero, fibonacci(numero));
             break;
             
      case 13: /*Sucesi�n de fibonacci iterativa*/       
             printf("\tSucesion de fibonacci iterativa para un n dado\n");
             printf("\tIntroduzca numero: ");
             scanf("%d", &numero);
             printf("\n\tfibonacciIterativo(%d)=%d\n", numero, fibonacciIterativo(numero));
             break;

      case 14: /*Busqueda lineal de un elemento en un vector*/       
             printf("\tBusqueda lineal de un elemento en el vector (5, 7, 3, 1, 11, 13, 17)\n");
             printf("\tIntroduzca numero: ");
             scanf("%d", &numero);
             printf("\n\tbusquedaLineal(%d)=%d\n", numero, busquedaLineal(V, 6, numero));
             break;
             
      case 15: /*Buscar los dos elementos mayores de un vector*/       
             printf("\tBuscar los dos elementos mayores del vector (5, 7, 3, 1, 11, 13, 17)\n");
             dosMayores(V, 6, &a, &b);
             printf("\n\tMayor1=%d     Mayor2=%d\n", a, b);
             break;
             
      case 16:/*Buscar los dos elementos mayores de un vector ALEATORIO*/       
             printf("\tBuscar los dos elementos mayores de un vector ALEATORIO\n");
             generaAleatorios(Valeatorio, (maxElem/2)-1);
             for(i=0; i<(maxElem/2); i++)
             {
             	printf("\tVectorAleatorio[%d]=%d\n", i, Valeatorio[i]);
             }             
             dosMayores(Valeatorio, (maxElem/2)-1, &a, &b);
             printf("\n\tMayor1=%d     Mayor2=%d\n", a, b);            
             break;                    
      case 100:
             salir=1;
             break;
    }
  }while(salir==0);
  
  printf("\n------------------------------------------\n");    	
}


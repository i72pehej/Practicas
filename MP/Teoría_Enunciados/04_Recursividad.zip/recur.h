/*------------------------------------------------------------------*/
/* EJEMPLOS BASICOS DE RECURSIVIDAD  EN C                           */
/*------------------------------------------------------------------*/

/*Cuando se tienen diferentes ficheros con m�dulos es posible
  que varios llamen a uno determinado. Si cada uno de estos
  incluye el fichero de prototipos, el compilador dar� un error,
  pues se estar� intentando incluir un mismo m�dulo m�s de una vez.
  Para evitar este problema hay que utilizar las directivas
  #IFNDEF, #DEFINE y #ENDIF
*/

#ifndef recur
#define recur
#define maxElem 20


/********************************************************************/
/*
   Nombre: factorial.
   Tipo: int.
   Objetivo: Calcula el factorial de un numero.
	     
   Parametros de entrada:
      - int n: El numero.
   Precondiciones: Ninguna.
   Devuelve: El valor del factorial.
   Fecha de creaci�n: 16-03-04.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int factorial(int n);
int factorialVerbose(int n);
int factorialMalVerbose(int* n);


/********************************************************************/
/*
   Nombre: potencia.
   Tipo: int.
   Objetivo: calcula base^exponente.	     
   Parametros de entrada:
      - int base: el valor de la base.
      - int exponente: el valor del exponente.
   Precondiciones: Ninguna.
   Devuelve: El valor de base^exponente.
   Fecha de creaci�n: 16-03-04.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int potencia(int base, int exponente);

/********************************************************************/
/*
   Nombre: suma.
   Tipo: int.
   Objetivo: calcula la suma de dos numeros de forma recursiva.	     
   Parametros de entrada:
      - int a: el primer sumando.
      - int b: el segundo sumando.
   Precondiciones: Ninguna.
   Devuelve: a+b.
   Fecha de creaci�n: 16-03-04.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int suma(int a, int b);

/********************************************************************/
/*
   Nombre: suma.
   Tipo: int.
   Objetivo: calcula el producto de dos numeros de forma recursiva.	     
   Parametros de entrada:
      - int a: el primer operando.
      - int b: el segundo operando.
   Precondiciones: Ninguna.
   Devuelve: a*b.
   Fecha de creaci�n: 16-03-04.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int producto(int a, int b);

/********************************************************************/
/*
   Nombre: sumaElementosVector.
   Tipo: int.
   Objetivo: suma los elementos de un vector hasta una determinada
             posicion de forma recursiva.	     
   Parametros de entrada:
      - int V[]: el vector.
      - int posicion: la posici�n (incluida) hasta la que se considera
                      el vector.
   Precondiciones: Ninguna.
   Devuelve: la suma de los elementos del vector.
   Fecha de creaci�n: 16-03-04.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int sumaElementosVector(int V[], int posicion);

/********************************************************************/
/*
   Nombre: mayor.
   Tipo: int.
   Objetivo: Calcula el mayor elemento de un vector de forma recursiva.	     
   Parametros de entrada:
      - int V[]: el vector.
      - int posicion: la posici�n (incluida) hasta la que se considera
                      el vector.
   Precondiciones: Ninguna.
   Devuelve: El mayor elemento del vector.
   Fecha de creaci�n: 16-03-04.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int mayor(int V[], int posicion);

/********************************************************************/
/*
   Nombre: escribirVector.
   Tipo: void.
   Objetivo: Escribe un vector de forma recursiva.	     
   Parametros de entrada:
      - int V[]: el vector.
      - int posicion: la posici�n (incluida) hasta la que se considera
                      el vector.
   Precondiciones: Ninguna.
   Devuelve: void.
   Fecha de creaci�n: 16-03-04.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void escribirVector(int V[], int posicion);

/********************************************************************/
/*
   Nombre: escribirVectorInvertido.
   Tipo: void.
   Objetivo: Escribe un vector en orden inversode forma recursiva.	     
   Parametros de entrada:
      - int V[]: el vector.
      - int posicion: la posici�n (incluida) hasta la que se considera
                      el vector.
   Precondiciones: Ninguna.
   Devuelve: void.
   Fecha de creaci�n: 16-03-04.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void escribirVectorInvertido(int V[], int posicion);

/********************************************************************/
/*
   Nombre: fibonacci.
   Tipo: int.
   Objetivo: Calcula el termino i-esimo de la sucesi�n de fibonacci.	     
   Parametros de entrada:
      - int n: el termino i-esimo a calcular.
   Precondiciones: Ninguna.
   Devuelve: el valor del termino i-esimo de la sucesi�n de fibonacci.
   Fecha de creaci�n: 16-03-04.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/

int fibonnacci(int n);
int fibonacciIterativo(int n);


/********************************************************************/
/*
   Nombre: busquedaLineal.
   Tipo: int.
   Objetivo: Realiza la busqueda lineal de un elemento en un vector.	     
   Parametros de entrada:
       - int V[]: el vector.
       - int posicion: la posici�n (incluida) hasta la que se considera
                      el vector.
       - int elemento: el elemento a buscar.
   Precondiciones: Ninguna.
   Devuelve: 1 si el elemento se encuentra en el vector, 0 en caso contrario.
   Fecha de creaci�n: 16-03-04.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
int busquedaLineal(int V[], int posicicon, int elemento);

/********************************************************************/
/*
   Nombre: dosMayores.
   Tipo: void.
   Objetivo: Busca los dos elementos mayores en un vector.	     
   Parametros de entrada:
       - int V[]: el vector.
       - int posicion: la posici�n (incluida) hasta la que se considera
                      el vector.
       - int* a: El mayor elemento del vector (por referencia).
       - int* b: El segundo mayor elemento del vector (por referencia).       
   Precondiciones: Ninguna.
   Devuelve: void.
   Fecha de creaci�n: 16-03-04.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
void dosMayores(int V[], int posicion, int* a, int* b);

/********************************************************************/
/*
   Nombre: generaAleatorios.
   Tipo: void.
   Objetivo: Genera un vector de numeros aleatorios.	     
   Parametros de entrada:
       - int V[]/ int* V: el vector (debe haber sido previamente creado o declarado).
       - int ultimo: la posici�n (incluida) hasta la que se considera
                      el vector.
   Precondiciones: Ninguna.
   Devuelve: void.
   Fecha de creaci�n: 16-03-04.
   Autor: Eva Gibaja Galindo
*/
/*******************************************************************/
//void generaAleatorios(int V[], int ultimo);
void generaAleatorios(int* V, int ultimo);

#endif

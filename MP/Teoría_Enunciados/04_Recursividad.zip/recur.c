/*------------------------------------------------------------------*/
/* EJEMPLOS BASICOS DE RECURSIVIDAD  EN C                           */
/*------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "recur.h"


/*------------------------------------------------------------------*/
int factorial(int n)
{
  int resultado;
  if (n==0)
    /*Caso base*/    
    resultado = 1;    
  else
    /*Cuerpo*/
    resultado = n*factorial(n-1);
  return(resultado);
}

/*------------------------------------------------------------------*/
int factorialVerbose(int n)
{
  int resultado;
  printf("\tEjecutando: factorial(%d)\n", n);    
  if (n==0)
  {
    /*Caso base*/
    printf("\n\t\tCaso base");    
    resultado = 1;    
  }  
  else
  {
    /*Cuerpo*/
    printf("\t\tLlamada recursiva a factorial(%d)\n", n-1);
    resultado = n*factorialVerbose(n-1);
  }
  printf("\tSaliendo de factorial(%d)\n", n);
  return(resultado); 
}

/*------------------------------------------------------------------*/
int factorialMalVerbose(int* n)
{
  int resultado;
  printf("\n\tEjecutando: factorial(%d)", *n);    
  if (*n==0)
  {
    /*Caso base*/
    printf("\n\t\tCaso base");    
    resultado = 1;    
  }  
  else
  {
    /*Cuerpo*/
  
    (*n)--;
    printf("\n\t\tLlamada recursiva: (%d+1)*factorial(%d)", *n, *n);
    resultado = factorialMalVerbose(n)*(*n+1);
    
    //Asi funciona correctamente, porque primero evalua (*n+1) y luego llama a factorial
    //resultado = (*n+1)*factorialMalVerbose(n);
    
  }
  
  printf("\n\tSaliendo de factorial(%d)", *n);
  return(resultado); 
}

/*------------------------------------------------------------------*/
int potencia(int base, int exponente)
{
  if (exponente==0)
  {
    //Caso base
    return(1);	
  }	
  else
  {
    //Cuerpo	
    return(base*potencia(base, exponente-1));
  }
}


/*------------------------------------------------------------------*/
int suma(int a, int b)
{
  if(b==0)
  {
    //Caso base
    return(a);
  }  
  else
  {
    //Cuerpo
    return(1+suma(a, b-1));
  }  	
}


/*------------------------------------------------------------------*/
int producto(int a, int b)
{
  if(b==0)
  {
    //Caso base
    return(0);
  }  
  else
  {
    //Cuerpo
    return(a+producto(a, b-1));
  }  	
}


/*------------------------------------------------------------------*/
int sumaElementosVector(int V[], int posicion)
{
  if(posicion==0)
  {
    return(V[0]);
  }
  else
  {
    return(V[posicion]+sumaElementosVector(V, posicion-1));	
  }	
}

/*------------------------------------------------------------------*/
int mayor(int V[], int posicion)
{
  int aux;
  if(posicion==0)	
  {
    return(V[0]);	
  }
  else
  {
    aux = mayor(V, posicion-1);
    if(V[posicion]>aux)
    {
      return(V[posicion]);	
    }
    else
    {
    	return(aux);
    }  
  }
}

/*------------------------------------------------------------------*/
void escribirVector(int V[], int posicion)
{
  
  if(posicion==0)
  {
    printf("\n\tV[%d]=%d", posicion, V[posicion]);     	
  }
  else
  {
    escribirVector(V, posicion-1);	   
    printf("\n\tV[%d]=%d", posicion, V[posicion]);   
  }  
}

/*------------------------------------------------------------------*/
void escribirVectorInvertido(int V[], int posicion)
{
  if(posicion==0)
  {
    printf("\n\tVinvertido[%d]=%d", posicion, V[posicion]);     	
  }
  else
  {
    printf("\n\tVinvertido[%d]=%d", posicion, V[posicion]);   
    escribirVectorInvertido(V, posicion-1);	       
  }  
}

/*------------------------------------------------------------------*/
int fibonacci(int n)
{
  if((n==1)||(n==2))	
  {
    return(1);
  }
  else
  {
    return(fibonacci(n-1)+fibonacci(n-2));
  }
}

/*------------------------------------------------------------------*/
int fibonacciIterativo(int n)
{
  
  int ant1 = 1; //Anterior
  int ant2 = 1; //Anteanterior
  int actual=0;
  int i;

  if((n==1)||(n==2))	
  {
    actual = 1; //no calcular nada
  }  
  else
  {
    for(i=3; i<=n; i++)
    {
    	//Suma los dos anteriores
    	actual = ant1+ant2;
    	
    	//actualiza ant2 y ant1
    	ant2 = ant1;
    	ant1 = actual;
    }    	
  }
  return(actual);  
}

/*------------------------------------------------------------------*/
int busquedaLineal(int V[], int posicion, int elemento)
{
  if(posicion<0)
  {
    //Primer caso base
    return(0);
  }
  else
  {
    if(V[posicion]==elemento)
    {
      //Segundo caso base
      return(1);	
    }
    else
    {
      return(busquedaLineal(V, posicion-1, elemento));	      
    }      
  }
}

/*------------------------------------------------------------------*/
void dosMayores(int V[], int posicion, int* a, int* b)
{
  if(posicion==1)
  {
    if(V[0]>V[1])
    {
      *a=V[0];
      *b=V[1];
    }
    else
    {
      *a=V[1];
      *b=V[0];    
    }
  
  }
  else
  {
    dosMayores(V, posicion-1, a, b);    
    
    if(V[posicion]>*a) //Caso1:-V[pos]------a-------b
    {
    	*b=*a;
    	*a=V[posicion];
    }
    else if(V[posicion]>*b)//Caso2: a----------V[pos]b------------b
    {
    	*b=V[posicion];
    }
 
  }
  
}
/*------------------------------------------------------------------*/
void generaAleatorios(int* numeros, int ultimo)
{
   time_t t;
   int i;

   /*inicializamos la semilla*/
   srand((unsigned) time(&t));

   for(i=0; i<=ultimo;i++)
   {
       //Numero aleatorio entre 0 y 100, por esto hacemos m�dulo
       numeros[i] = rand() % 101;
   } 
}
